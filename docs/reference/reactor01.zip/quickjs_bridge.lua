--[[
  quickjs_bridge.lua
  
  LuaJIT FFI bindings to QuickJS. Creates a JavaScript runtime embedded
  inside the Love2D process. Exposes two host functions to JS:
  
    __hostFlush(json)     -- JS sends mutation commands to Lua
    __hostGetEvents()     -- JS polls for input events from Lua
    
  This is the same architectural pattern as React Native's JSI bridge,
  except simpler because we only need unidirectional command buffers.
]]

local ffi = require("ffi")
local json = require("json")  -- need a JSON lib (cjson, lunajson, etc.)

-- ────────────────────────────────────────────────────────
-- QuickJS C API declarations
-- Subset needed for evaluation + host function exposure
-- ────────────────────────────────────────────────────────

ffi.cdef[[
  typedef struct JSRuntime JSRuntime;
  typedef struct JSContext JSContext;

  /* JSValue is a 128-bit struct on 64-bit systems in newer QuickJS.
     For simplicity we treat it as opaque and use helper functions.
     In practice you'd match the exact ABI of your QuickJS build. */
  
  typedef struct { int64_t u; int64_t tag; } JSValue;
  
  JSRuntime *JS_NewRuntime(void);
  void JS_SetMaxStackSize(JSRuntime *rt, size_t stack_size);
  void JS_SetMemoryLimit(JSRuntime *rt, size_t limit);
  JSContext *JS_NewContext(JSRuntime *rt);
  void JS_FreeContext(JSContext *ctx);
  void JS_FreeRuntime(JSRuntime *rt);
  void JS_FreeValue(JSContext *ctx, JSValue val);
  
  /* Evaluation */
  JSValue JS_Eval(JSContext *ctx, const char *input, size_t input_len,
                  const char *filename, int eval_flags);
  
  /* String conversion */
  const char *JS_ToCString(JSContext *ctx, JSValue val);
  void JS_FreeCString(JSContext *ctx, const char *ptr);
  JSValue JS_NewString(JSContext *ctx, const char *str);
  
  /* Object/property access */
  JSValue JS_GetGlobalObject(JSContext *ctx);
  JSValue JS_GetPropertyStr(JSContext *ctx, JSValue this_obj, const char *prop);
  int JS_SetPropertyStr(JSContext *ctx, JSValue this_obj, const char *prop, JSValue val);
  
  /* Function creation */
  typedef JSValue (*JSCFunction)(JSContext *ctx, JSValue this_val,
                                  int argc, JSValue *argv);
  JSValue JS_NewCFunction(JSContext *ctx, JSCFunction func, const char *name, int length);
  
  /* Type checking */
  int JS_IsException(JSValue val);
  int JS_IsUndefined(JSValue val);
  JSValue JS_GetException(JSContext *ctx);
  
  /* Job queue (promises, async) */
  int JS_ExecutePendingJob(JSRuntime *rt, JSContext **pctx);
  
  /* Standard library init (console, setTimeout, etc.) */
  void js_std_init_handlers(JSRuntime *rt);
  void js_std_add_helpers(JSContext *ctx, int argc, char **argv);
]]

local JS_EVAL_TYPE_GLOBAL = 0
local JS_EVAL_TYPE_MODULE = 1
local JS_EVAL_FLAG_STRICT = 8

-- ────────────────────────────────────────────────────────
-- Bridge object
-- ────────────────────────────────────────────────────────

local Bridge = {}
Bridge.__index = Bridge

function Bridge.new(libpath)
  libpath = libpath or "lib/libquickjs"
  
  local qjs = ffi.load(libpath)
  
  local self = setmetatable({
    qjs = qjs,
    rt = nil,
    ctx = nil,
    commandBuffer = {},
    eventQueue = {},
    _callbacks = {},  -- prevent GC of FFI callbacks
  }, Bridge)
  
  -- Create runtime with reasonable limits for game UI
  self.rt = qjs.JS_NewRuntime()
  qjs.JS_SetMaxStackSize(self.rt, 1024 * 1024)      -- 1MB stack
  qjs.JS_SetMemoryLimit(self.rt, 64 * 1024 * 1024)   -- 64MB heap
  
  self.ctx = qjs.JS_NewContext(self.rt)
  
  -- Initialize standard handlers (gives us console.log, setTimeout, etc.)
  -- Note: js_std_add_helpers may not exist in all QuickJS builds.
  -- If using a minimal build, you'll need to polyfill setTimeout/console.
  pcall(function()
    qjs.js_std_init_handlers(self.rt)
    qjs.js_std_add_helpers(self.ctx, 0, nil)
  end)
  
  -- Expose host functions
  self:_exposeHostFlush()
  self:_exposeHostGetEvents()
  self:_exposeHostLog()
  
  -- Polyfill basics if std helpers aren't available
  self:eval([[
    if (typeof console === 'undefined') {
      globalThis.console = {
        log: function() { __hostLog(Array.from(arguments).join(' ')); },
        warn: function() { __hostLog('[WARN] ' + Array.from(arguments).join(' ')); },
        error: function() { __hostLog('[ERROR] ' + Array.from(arguments).join(' ')); },
      };
    }
    if (typeof setTimeout === 'undefined') {
      // QuickJS doesn't have timers by default — we approximate with a job queue
      const _timers = [];
      let _timerId = 0;
      globalThis.setTimeout = function(fn, ms) {
        const id = ++_timerId;
        _timers.push({ id, fn, at: Date.now() + (ms || 0) });
        return id;
      };
      globalThis.clearTimeout = function(id) {
        const idx = _timers.findIndex(t => t.id === id);
        if (idx !== -1) _timers.splice(idx, 1);
      };
      globalThis.setInterval = function(fn, ms) {
        const id = ++_timerId;
        function tick() {
          fn();
          const t = _timers.find(t => t.id === id);
          if (t) t.at = Date.now() + ms;
        }
        _timers.push({ id, fn: tick, at: Date.now() + ms, interval: true });
        return id;
      };
      globalThis.clearInterval = globalThis.clearTimeout;
      // Tick function called from Lua
      globalThis.__tickTimers = function() {
        const now = Date.now();
        const ready = _timers.filter(t => t.at <= now);
        for (const t of ready) {
          t.fn();
          if (!t.interval) {
            const idx = _timers.indexOf(t);
            if (idx !== -1) _timers.splice(idx, 1);
          }
        }
      };
    }
  ]], "<polyfills>")
  
  return self
end

-- ────────────────────────────────────────────────────────
-- Host function: __hostFlush
-- Called by React renderer to send mutation commands to Lua
-- ────────────────────────────────────────────────────────

function Bridge:_exposeHostFlush()
  local selfRef = self
  local cb = ffi.cast("JSCFunction", function(ctx, this_val, argc, argv)
    if argc < 1 then return ffi.new("JSValue", {0, 3}) end  -- undefined
    
    local cstr = selfRef.qjs.JS_ToCString(ctx, argv[0])
    if cstr ~= nil then
      local str = ffi.string(cstr)
      selfRef.qjs.JS_FreeCString(ctx, cstr)
      
      -- Parse JSON commands
      local ok, commands = pcall(json.decode, str)
      if ok and type(commands) == "table" then
        for _, cmd in ipairs(commands) do
          selfRef.commandBuffer[#selfRef.commandBuffer + 1] = cmd
        end
      else
        print("[react-love] Failed to parse commands: " .. tostring(str):sub(1, 200))
      end
    end
    
    return ffi.new("JSValue", {0, 3})  -- undefined
  end)
  self._callbacks[#self._callbacks + 1] = cb  -- prevent GC
  
  local global = self.qjs.JS_GetGlobalObject(self.ctx)
  local fn = self.qjs.JS_NewCFunction(self.ctx, cb, "__hostFlush", 1)
  self.qjs.JS_SetPropertyStr(self.ctx, global, "__hostFlush", fn)
  self.qjs.JS_FreeValue(self.ctx, global)
end

-- ────────────────────────────────────────────────────────
-- Host function: __hostGetEvents
-- Called by React event dispatcher to poll for input events
-- ────────────────────────────────────────────────────────

function Bridge:_exposeHostGetEvents()
  local selfRef = self
  local cb = ffi.cast("JSCFunction", function(ctx, this_val, argc, argv)
    local events = selfRef.eventQueue
    selfRef.eventQueue = {}
    
    local str = json.encode(events)
    return selfRef.qjs.JS_NewString(ctx, str)
  end)
  self._callbacks[#self._callbacks + 1] = cb
  
  local global = self.qjs.JS_GetGlobalObject(self.ctx)
  local fn = self.qjs.JS_NewCFunction(self.ctx, cb, "__hostGetEvents", 0)
  self.qjs.JS_SetPropertyStr(self.ctx, global, "__hostGetEvents", fn)
  self.qjs.JS_FreeValue(self.ctx, global)
end

-- ────────────────────────────────────────────────────────
-- Host function: __hostLog
-- Routes console.log from JS to Love2D's print
-- ────────────────────────────────────────────────────────

function Bridge:_exposeHostLog()
  local cb = ffi.cast("JSCFunction", function(ctx, this_val, argc, argv)
    if argc >= 1 then
      local cstr = ffi.C.JS_ToCString(ctx, argv[0])
      if cstr ~= nil then
        print("[JS] " .. ffi.string(cstr))
        ffi.C.JS_FreeCString(ctx, cstr)
      end
    end
    return ffi.new("JSValue", {0, 3})
  end)
  self._callbacks[#self._callbacks + 1] = cb
  
  local global = self.qjs.JS_GetGlobalObject(self.ctx)
  local fn = self.qjs.JS_NewCFunction(self.ctx, cb, "__hostLog", 1)
  self.qjs.JS_SetPropertyStr(self.ctx, global, "__hostLog", fn)
  self.qjs.JS_FreeValue(self.ctx, global)
end

-- ────────────────────────────────────────────────────────
-- Public API
-- ────────────────────────────────────────────────────────

function Bridge:eval(code, filename)
  filename = filename or "<eval>"
  local val = self.qjs.JS_Eval(
    self.ctx, code, #code, filename, JS_EVAL_TYPE_GLOBAL
  )
  
  if self.qjs.JS_IsException(val) ~= 0 then
    local exc = self.qjs.JS_GetException(self.ctx)
    local cstr = self.qjs.JS_ToCString(self.ctx, exc)
    local msg = cstr ~= nil and ffi.string(cstr) or "unknown error"
    if cstr ~= nil then self.qjs.JS_FreeCString(self.ctx, cstr) end
    self.qjs.JS_FreeValue(self.ctx, exc)
    error("[QuickJS] " .. msg)
  end
  
  self.qjs.JS_FreeValue(self.ctx, val)
end

--- Tick the JS event loop (promises, microtasks, timers)
function Bridge:tick()
  -- Drain pending microtasks
  local ctx_ptr = ffi.new("JSContext*[1]")
  while self.qjs.JS_ExecutePendingJob(self.rt, ctx_ptr) > 0 do end
  
  -- Tick polyfilled timers
  pcall(function() self:eval("if (globalThis.__tickTimers) __tickTimers();") end)
end

--- Drain the command buffer (called by Love2D each frame)
function Bridge:drainCommands()
  local cmds = self.commandBuffer
  self.commandBuffer = {}
  return cmds
end

--- Push an input event for JS to pick up
function Bridge:pushEvent(event)
  self.eventQueue[#self.eventQueue + 1] = event
end

--- Clean shutdown
function Bridge:destroy()
  self.qjs.JS_FreeContext(self.ctx)
  self.qjs.JS_FreeRuntime(self.rt)
  self.ctx = nil
  self.rt = nil
end

return Bridge
