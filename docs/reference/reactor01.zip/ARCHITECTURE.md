# react-love: Literal React Inside Love2D

## The Idea

Stop reimplementing React in Lua. Run the *actual* React reconciler — the same
code that powers react-dom and react-native — inside an embedded JavaScript
engine, and use Love2D as a custom renderer target.

This is not a metaphor. This is how react-native works: React runs in a JS
engine (Hermes/JSC), computes a tree diff, and sends mutation commands over a
bridge to the native side. We do the same thing, except:

- **JS engine**: QuickJS (210KB, pure C, ES2020, embeddable via LuaJIT FFI)
- **Bridge**: Shared command buffer between JS and Lua via FFI
- **Native side**: Love2D's retained element tree + flexbox layout + paint

```
┌─────────────────────────────────────────────────────┐
│                    Your Game Code                     │
│                                                       │
│   import { useState } from 'react'                    │
│   import { View, Text, Image } from 'react-love'     │
│                                                       │
│   function HUD({ health, score }) {                   │
│     const [expanded, setExpanded] = useState(false)   │
│     return (                                          │
│       <View style={{ flexDirection: 'row', gap: 8 }}>│
│         <HealthBar value={health} />                  │
│         <Text style={{ color: '#fff' }}>{score}</Text>│
│       </View>                                         │
│     )                                                 │
│   }                                                   │
│                                                       │
└──────────────────────┬──────────────────────────────┘
                       │  JSX → React.createElement()
                       ▼
┌─────────────────────────────────────────────────────┐
│              QuickJS (embedded via FFI)               │
│                                                       │
│   react (actual npm package, bundled)                 │
│   react-reconciler (actual npm package)               │
│   react-love-hostconfig.js (our custom renderer)     │
│                                                       │
│   Reconciler diffs virtual tree                       │
│   Host config emits mutation commands:                │
│     CREATE  { id: 7, type: "View", props: {...} }    │
│     APPEND  { parent: 3, child: 7 }                  │
│     UPDATE  { id: 7, props: { style: {...} } }       │
│     REMOVE  { parent: 3, child: 7 }                  │
│                                                       │
└──────────────────────┬──────────────────────────────┘
                       │  Command buffer (JSON via FFI)
                       ▼
┌─────────────────────────────────────────────────────┐
│                 Love2D (Lua/LuaJIT)                   │
│                                                       │
│   bridge.lua — reads command buffer, applies to tree  │
│   layout.lua — flexbox over retained element tree     │
│   painter.lua — Love2D draw calls from layout rects   │
│   events.lua — hit test + dispatch back to JS         │
│                                                       │
│   love.update → flush commands → relayout if dirty    │
│   love.draw   → paint retained tree                   │
│   love.mouse* → hit test → send event to JS           │
│                                                       │
└─────────────────────────────────────────────────────┘
```

## Why QuickJS

The JS engine choice matters. Options considered:

| Engine   | Size   | ES Level | Embeddable | LuaJIT FFI | Verdict          |
|----------|--------|----------|------------|------------|------------------|
| V8       | ~30MB  | ES2024   | Hard       | No         | Way too heavy    |
| Hermes   | ~3MB   | ES6+     | Medium     | Possible   | Facebook-coupled |
| Duktape  | ~300KB | ES5.1    | Easy       | Yes        | Too old for React|
| QuickJS  | ~210KB | ES2020   | Easy       | Yes        | ✓ Perfect fit    |
| MuJS     | ~200KB | ES5.1    | Easy       | Yes        | Too old          |

QuickJS is a single .c + .h file, compiles to a ~350KB shared library, supports
async/await (which React concurrent mode needs), and has a clean C API that maps
directly to LuaJIT's FFI. Bellard wrote it; it's solid.

## Part 1: QuickJS FFI Bridge (Lua side)

The core: load libquickjs.so, create a runtime, evaluate bundled JS, expose
host functions for the command buffer and event dispatch.

```lua
-- quickjs_bridge.lua
local ffi = require("ffi")

ffi.cdef[[
  // QuickJS core types
  typedef struct JSRuntime JSRuntime;
  typedef struct JSContext JSContext;
  typedef uint64_t JSValue;  // NaN-boxed on 64-bit

  // Lifecycle
  JSRuntime *JS_NewRuntime(void);
  JSContext *JS_NewContext(JSRuntime *rt);
  void JS_FreeContext(JSContext *ctx);
  void JS_FreeRuntime(JSRuntime *rt);

  // Evaluation
  JSValue JS_Eval(JSContext *ctx, const char *input, size_t input_len,
                  const char *filename, int eval_flags);

  // Value helpers
  const char *JS_ToCString(JSContext *ctx, JSValue val);
  void JS_FreeCString(JSContext *ctx, const char *ptr);
  void JS_FreeValue(JSContext *ctx, JSValue val);

  // Global object
  JSValue JS_GetGlobalObject(JSContext *ctx);

  // Property access
  JSValue JS_GetPropertyStr(JSContext *ctx, JSValue this_obj, const char *prop);
  int JS_SetPropertyStr(JSContext *ctx, JSValue this_obj, const char *prop, JSValue val);

  // Function creation (for host callbacks)
  typedef JSValue (*JSCFunction)(JSContext *ctx, JSValue this_val,
                                  int argc, JSValue *argv);
  JSValue JS_NewCFunction(JSContext *ctx, JSCFunction func, const char *name, int length);

  // String creation
  JSValue JS_NewString(JSContext *ctx, const char *str);

  // Pending jobs (for promises/async)
  int JS_ExecutePendingJob(JSRuntime *rt, JSContext **pctx);

  // Exception handling
  JSValue JS_GetException(JSContext *ctx);
  int JS_IsException(JSValue val);
]]

local JS_EVAL_TYPE_GLOBAL = 0
local JS_EVAL_TYPE_MODULE = 1

local qjs = ffi.load("quickjs")  -- or path to libquickjs.so

local Bridge = {}

function Bridge.new()
  local self = {}
  self.rt = qjs.JS_NewRuntime()
  self.ctx = qjs.JS_NewContext(self.rt)
  self.commandBuffer = {}  -- commands from JS side
  self.eventQueue = {}     -- events going TO JS side

  -- Expose __hostFlush to JS: called by the renderer to push commands
  local flushCallback = ffi.cast("JSCFunction", function(ctx, this_val, argc, argv)
    -- argv[0] is a JSON string of commands
    local json_str = ffi.string(qjs.JS_ToCString(ctx, argv[0]))
    -- decode and append to command buffer
    local commands = Bridge._decodeJSON(json_str)
    for _, cmd in ipairs(commands) do
      self.commandBuffer[#self.commandBuffer + 1] = cmd
    end
    return 0  -- undefined
  end)

  local global = qjs.JS_GetGlobalObject(self.ctx)
  local fn = qjs.JS_NewCFunction(self.ctx, flushCallback, "__hostFlush", 1)
  qjs.JS_SetPropertyStr(self.ctx, global, "__hostFlush", fn)
  qjs.JS_FreeValue(self.ctx, global)

  -- Expose __hostGetEvents: JS calls this to poll for input events
  local eventsCallback = ffi.cast("JSCFunction", function(ctx, this_val, argc, argv)
    local json = Bridge._encodeJSON(self.eventQueue)
    self.eventQueue = {}
    return qjs.JS_NewString(ctx, json)
  end)

  global = qjs.JS_GetGlobalObject(self.ctx)
  fn = qjs.JS_NewCFunction(self.ctx, eventsCallback, "__hostGetEvents", 0)
  qjs.JS_SetPropertyStr(self.ctx, global, "__hostGetEvents", fn)
  qjs.JS_FreeValue(self.ctx, global)

  return setmetatable(self, { __index = Bridge })
end

function Bridge:eval(code, filename)
  filename = filename or "<eval>"
  local val = qjs.JS_Eval(self.ctx, code, #code, filename, JS_EVAL_TYPE_GLOBAL)
  if qjs.JS_IsException(val) ~= 0 then
    local exc = qjs.JS_GetException(self.ctx)
    local msg = ffi.string(qjs.JS_ToCString(self.ctx, exc))
    qjs.JS_FreeValue(self.ctx, exc)
    error("QuickJS error: " .. msg)
  end
  qjs.JS_FreeValue(self.ctx, val)
end

function Bridge:evalModule(code, filename)
  filename = filename or "<module>"
  local val = qjs.JS_Eval(self.ctx, code, #code, filename, JS_EVAL_TYPE_MODULE)
  if qjs.JS_IsException(val) ~= 0 then
    local exc = qjs.JS_GetException(self.ctx)
    local msg = ffi.string(qjs.JS_ToCString(self.ctx, exc))
    qjs.JS_FreeValue(self.ctx, exc)
    error("QuickJS error: " .. msg)
  end
  qjs.JS_FreeValue(self.ctx, val)
end

function Bridge:tick()
  -- drain pending JS jobs (promises, microtasks)
  local ctx_ptr = ffi.new("JSContext*[1]")
  while qjs.JS_ExecutePendingJob(self.rt, ctx_ptr) > 0 do end
end

function Bridge:drainCommands()
  local cmds = self.commandBuffer
  self.commandBuffer = {}
  return cmds
end

function Bridge:pushEvent(event)
  self.eventQueue[#self.eventQueue + 1] = event
end

function Bridge:destroy()
  qjs.JS_FreeContext(self.ctx)
  qjs.JS_FreeRuntime(self.rt)
end

-- Minimal JSON encode/decode (in practice, use a Lua JSON library)
function Bridge._decodeJSON(str)
  -- use cjson or lunajson in real code
  return loadstring("return " .. str)()  -- UNSAFE, placeholder
end

function Bridge._encodeJSON(tbl)
  -- use cjson or lunajson in real code
  return "{}"  -- placeholder
end

return Bridge
```

## Part 2: React Custom Renderer (JS side)

This is the host config — the interface between React's reconciler and Love2D.
It's standard `react-reconciler` usage, the same pattern as react-dom, react-native,
ink, react-three-fiber.

```javascript
// react-love-renderer.js
// This gets bundled (via esbuild) into a single file loaded by QuickJS

import React from 'react';
import Reconciler from 'react-reconciler';

let nodeIdCounter = 0;
let pendingCommands = [];

function flushToHost() {
  if (pendingCommands.length === 0) return;
  // __hostFlush is exposed by the Lua FFI bridge
  __hostFlush(JSON.stringify(pendingCommands));
  pendingCommands = [];
}

function emit(cmd) {
  pendingCommands.push(cmd);
}

// ──────────────────────────────────────────────────
// Host Config: tells React how to talk to Love2D
// ──────────────────────────────────────────────────

const hostConfig = {
  supportsMutation: true,
  supportsPersistence: false,

  // ─── Instance creation ───

  createInstance(type, props, rootContainer, hostContext, fiber) {
    const id = ++nodeIdCounter;
    const { children, ...cleanProps } = props;
    emit({ op: 'CREATE', id, type, props: cleanProps });
    return { id, type, props: cleanProps, children: [] };
  },

  createTextInstance(text, rootContainer, hostContext, fiber) {
    const id = ++nodeIdCounter;
    emit({ op: 'CREATE_TEXT', id, text });
    return { id, type: '__TEXT__', text };
  },

  // ─── Tree assembly (during initial render) ───

  appendInitialChild(parent, child) {
    parent.children.push(child);
    emit({ op: 'APPEND', parentId: parent.id, childId: child.id });
  },

  appendChild(parent, child) {
    parent.children.push(child);
    emit({ op: 'APPEND', parentId: parent.id, childId: child.id });
  },

  appendChildToContainer(container, child) {
    emit({ op: 'APPEND_TO_ROOT', childId: child.id });
  },

  // ─── Updates ───

  prepareUpdate(instance, type, oldProps, newProps) {
    const { children: _oc, ...oldClean } = oldProps;
    const { children: _nc, ...newClean } = newProps;
    // Shallow diff
    const updates = {};
    let hasUpdates = false;
    for (const key in newClean) {
      if (newClean[key] !== oldClean[key]) {
        updates[key] = newClean[key];
        hasUpdates = true;
      }
    }
    for (const key in oldClean) {
      if (!(key in newClean)) {
        updates[key] = null;
        hasUpdates = true;
      }
    }
    return hasUpdates ? updates : null;
  },

  commitUpdate(instance, updatePayload, type, oldProps, newProps) {
    Object.assign(instance.props, updatePayload);
    emit({ op: 'UPDATE', id: instance.id, props: updatePayload });
  },

  commitTextUpdate(textInstance, oldText, newText) {
    textInstance.text = newText;
    emit({ op: 'UPDATE_TEXT', id: textInstance.id, text: newText });
  },

  // ─── Removal ───

  removeChild(parent, child) {
    const idx = parent.children.indexOf(child);
    if (idx !== -1) parent.children.splice(idx, 1);
    emit({ op: 'REMOVE', parentId: parent.id, childId: child.id });
  },

  removeChildFromContainer(container, child) {
    emit({ op: 'REMOVE_FROM_ROOT', childId: child.id });
  },

  // ─── Insertion ───

  insertBefore(parent, child, before) {
    const idx = parent.children.indexOf(before);
    parent.children.splice(idx, 0, child);
    emit({ op: 'INSERT_BEFORE', parentId: parent.id, childId: child.id, beforeId: before.id });
  },

  insertInContainerBefore(container, child, before) {
    emit({ op: 'INSERT_BEFORE_ROOT', childId: child.id, beforeId: before.id });
  },

  // ─── Required stubs ───

  finalizeInitialChildren() { return false; },
  getPublicInstance(instance) { return instance; },
  prepareForCommit() { return null; },
  resetAfterCommit() {
    // This fires after every React commit — flush all commands to Lua
    flushToHost();
  },
  shouldSetTextContent() { return false; },
  getRootHostContext() { return {}; },
  getChildHostContext(parentContext) { return parentContext; },
  clearContainer() {},
  preparePortalMount() {},
  scheduleTimeout: setTimeout,
  cancelTimeout: clearTimeout,
  noTimeout: -1,
  isPrimaryRenderer: true,
  supportsMicrotasks: true,
  scheduleMicrotask: queueMicrotask,
  getCurrentEventPriority() { return 0b0000000000000000000000000010000; }, // DefaultEventPriority
  getInstanceFromNode() { return null; },
  beforeActiveInstanceBlur() {},
  afterActiveInstanceBlur() {},
  prepareScopeUpdate() {},
  getInstanceFromScope() { return null; },
  detachDeletedInstance() {},
};

const reconciler = Reconciler(hostConfig);

// ──────────────────────────────────────────────────
// Public API: what game code imports
// ──────────────────────────────────────────────────

const roots = new Map();

export function render(element, container = { id: 0 }) {
  let root = roots.get(container);
  if (!root) {
    root = reconciler.createContainer(container, 0, null, false, null, '', null, null);
    roots.set(container, root);
  }
  reconciler.updateContainer(element, root, null, null);
  return container;
}

// ──────────────────────────────────────────────────
// Built-in host components (the primitives)
// ──────────────────────────────────────────────────
// These are just strings — React resolves them as host component types.
// The Lua renderer knows how to paint each one.

// <View> — the "div" of react-love. A flexbox container.
// <Text> — renders text with Love2D fonts.
// <Image> — renders a Love2D image.
// <Canvas> — escape hatch: raw Love2D draw callback.

// Usage:
//   <View style={{ flexDirection: 'row', padding: 16, backgroundColor: [0.2, 0.2, 0.3, 1] }}>
//     <Text style={{ color: [1, 1, 1, 1], fontSize: 16 }}>Hello</Text>
//   </View>

// ──────────────────────────────────────────────────
// Event polling (called from Lua via JS_Eval)
// ──────────────────────────────────────────────────

// The Lua side pushes events to __hostGetEvents. The JS side polls
// them and dispatches to the correct React event handler.

const eventHandlers = new Map();  // nodeId -> { onClick, onPointerEnter, ... }

export function _registerHandlers(nodeId, handlers) {
  eventHandlers.set(nodeId, handlers);
}

export function _pollAndDispatchEvents() {
  const eventsJson = __hostGetEvents();
  const events = JSON.parse(eventsJson);
  for (const event of events) {
    const handlers = eventHandlers.get(event.targetId);
    if (handlers && handlers[event.type]) {
      handlers[event.type](event);
    }
  }
}
```

## Part 3: Lua-side Command Interpreter + Retained Tree

```lua
-- command_interpreter.lua
-- Reads commands from the JS bridge and maintains the retained element tree.

local Interpreter = {}

function Interpreter.new()
  local self = {
    nodes = {},     -- id -> node
    rootChildren = {},
    dirty = false,
  }
  return setmetatable(self, { __index = Interpreter })
end

function Interpreter:apply(commands)
  for _, cmd in ipairs(commands) do
    local op = cmd.op

    if op == "CREATE" then
      self.nodes[cmd.id] = {
        id = cmd.id,
        type = cmd.type,
        props = cmd.props,
        style = cmd.props and cmd.props.style or {},
        children = {},
        parent = nil,
      }
      self.dirty = true

    elseif op == "CREATE_TEXT" then
      self.nodes[cmd.id] = {
        id = cmd.id,
        type = "__TEXT__",
        text = cmd.text,
        style = {},
        children = {},
        parent = nil,
      }
      self.dirty = true

    elseif op == "APPEND" or op == "APPEND_TO_ROOT" then
      local child = self.nodes[cmd.childId]
      if op == "APPEND_TO_ROOT" then
        self.rootChildren[#self.rootChildren + 1] = child
      else
        local parent = self.nodes[cmd.parentId]
        if parent and child then
          child.parent = parent
          parent.children[#parent.children + 1] = child
        end
      end
      self.dirty = true

    elseif op == "UPDATE" then
      local node = self.nodes[cmd.id]
      if node then
        for k, v in pairs(cmd.props) do
          node.props[k] = v
          if k == "style" then node.style = v end
        end
        self.dirty = true
      end

    elseif op == "UPDATE_TEXT" then
      local node = self.nodes[cmd.id]
      if node then
        node.text = cmd.text
        self.dirty = true
      end

    elseif op == "REMOVE" or op == "REMOVE_FROM_ROOT" then
      local child = self.nodes[cmd.childId]
      if op == "REMOVE_FROM_ROOT" then
        for i, c in ipairs(self.rootChildren) do
          if c.id == cmd.childId then
            table.remove(self.rootChildren, i)
            break
          end
        end
      else
        local parent = self.nodes[cmd.parentId]
        if parent then
          for i, c in ipairs(parent.children) do
            if c.id == cmd.childId then
              table.remove(parent.children, i)
              break
            end
          end
        end
      end
      self.nodes[cmd.childId] = nil
      self.dirty = true

    elseif op == "INSERT_BEFORE" then
      local parent = self.nodes[cmd.parentId]
      local child = self.nodes[cmd.childId]
      if parent and child then
        child.parent = parent
        for i, c in ipairs(parent.children) do
          if c.id == cmd.beforeId then
            table.insert(parent.children, i, child)
            break
          end
        end
      end
      self.dirty = true
    end
  end
end

-- Build the tree structure the layout engine expects
function Interpreter:getTree()
  if #self.rootChildren == 1 then
    return self.rootChildren[1]
  end
  -- wrap multiple roots in a virtual container
  return {
    id = 0,
    type = "View",
    style = { width = "100%", height = "100%" },
    children = self.rootChildren,
    props = {},
  }
end

return Interpreter
```

## Part 4: The Game Loop Integration

```lua
-- main.lua (Love2D entry point)

local Bridge = require("quickjs_bridge")
local Interpreter = require("command_interpreter")
local Layout = require("layout")    -- flexbox engine from reactor.lua
local Painter = require("painter")  -- Love2D draw calls

local bridge
local interpreter
local bundledJS  -- your React app, bundled by esbuild into a single file

function love.load()
  love.window.setTitle("react-love")
  love.window.setMode(1024, 768, { resizable = true })

  -- 1. Initialize QuickJS
  bridge = Bridge.new()
  interpreter = Interpreter.new()

  -- 2. Load the bundled JS (React + your app + renderer)
  bundledJS = love.filesystem.read("bundle.js")
  bridge:eval(bundledJS, "bundle.js")

  -- 3. Kick off the initial render
  bridge:eval("render(React.createElement(App))")
end

function love.update(dt)
  -- 1. Push any queued input events to JS
  bridge:tick()

  -- 2. Tell JS to poll events and dispatch to React handlers
  bridge:eval("_pollAndDispatchEvents()")

  -- 3. Tick microtasks (promises, setState batching)
  bridge:tick()

  -- 4. Drain commands from JS → apply to retained tree
  local commands = bridge:drainCommands()
  if #commands > 0 then
    interpreter:apply(commands)
  end

  -- 5. Re-layout if tree changed
  if interpreter.dirty then
    local tree = interpreter:getTree()
    local w = love.graphics.getWidth()
    local h = love.graphics.getHeight()
    Layout.compute(tree, 0, 0, w, h)
    interpreter.dirty = false
  end
end

function love.draw()
  local tree = interpreter:getTree()
  Painter.paint(tree)
end

function love.mousepressed(x, y, button)
  -- hit test against computed layout, send event to JS
  local tree = interpreter:getTree()
  local hit = Events.hitTest(tree, x, y)
  if hit then
    bridge:pushEvent({
      type = "onClick",
      targetId = hit.id,
      x = x, y = y, button = button,
    })
  end
end

function love.mousereleased(x, y, button)
  -- similar
end

function love.mousemoved(x, y, dx, dy)
  -- hover tracking, pointerEnter/pointerLeave
end
```

## Build Pipeline

The JS side needs bundling — you can't load individual npm modules into QuickJS.
A single esbuild invocation collapses everything:

```bash
# Install dependencies
npm init -y
npm install react react-reconciler

# Bundle everything into one file QuickJS can evaluate
npx esbuild \
  --bundle \
  --format=iife \
  --global-name=ReactLove \
  --target=es2020 \
  --outfile=game/bundle.js \
  src/index.jsx

# The output is a single JS file containing:
#   - React runtime
#   - react-reconciler
#   - Your host config
#   - Your game components
#   - An IIFE that exposes render(), App, etc. as globals
```

Your project structure:

```
my-game/
├── src/                          # JS/JSX source
│   ├── index.jsx                 # Entry: imports App, calls render()
│   ├── renderer.js               # react-reconciler host config
│   ├── components/
│   │   ├── App.jsx               # Your root component
│   │   ├── HUD.jsx               # Game HUD
│   │   └── Inventory.jsx         # Inventory panel
│   └── hooks/
│       ├── useGameState.js       # Custom hook reading game state
│       └── useSpring.js          # Animation hook
├── game/                         # Love2D project
│   ├── main.lua                  # love.load/update/draw
│   ├── quickjs_bridge.lua        # FFI bindings to QuickJS
│   ├── command_interpreter.lua   # Applies JS commands to tree
│   ├── layout.lua                # Flexbox engine
│   ├── painter.lua               # Love2D draw calls
│   ├── events.lua                # Hit testing + dispatch
│   ├── bundle.js                 # (generated) bundled React app
│   └── lib/
│       └── libquickjs.so         # compiled QuickJS library
├── package.json
├── esbuild.config.js
└── Makefile
```

## What This Gives You That Nothing Else Does

1. **Actual React**: useState, useEffect, useContext, useMemo, Suspense,
   ErrorBoundary, concurrent features — all real, all tested by Facebook at
   scale. No Lua reimplementation bugs.

2. **The entire npm ecosystem**: Want framer-motion-style animations? `npm install`.
   Want Zustand for state management? `npm install`. Want Immer for immutable
   state updates? `npm install`. It all works because it's real JavaScript.

3. **JSX**: Actual JSX via esbuild/Babel/SWC. Not `h("box", {style=...})` Lua
   tables. Real `<View style={{...}}>` syntax.

4. **TypeScript**: Full type safety for your UI components. The game logic in
   Lua stays in Lua. The UI layer gets TypeScript.

5. **Hot reload**: esbuild has `--watch`. QuickJS can re-evaluate a new bundle.
   Your Lua game loop keeps running while you iterate on UI in real-time.

6. **Separation of concerns**: Game simulation in Lua (where LuaJIT shines for
   performance). UI rendering also in Lua (Love2D's draw calls). UI *logic* in
   JS/TS (where React shines for declarative state management). Clean boundary.

## What's Hard / Where the Risk Is

**QuickJS performance**: QuickJS is 10-30x slower than V8. For UI reconciliation
this is fine — React diffs are microseconds. For heavy computation, keep it in Lua.

**Bridge overhead**: Serializing commands as JSON strings crossing FFI is not
zero-cost. For a game HUD with ~100 elements updating at 60fps, it's negligible.
For a UI with 10,000 nodes, you'd want a binary protocol (MessagePack or a
shared memory ring buffer via FFI).

**Memory management**: QuickJS and LuaJIT have independent GCs. The command
buffer creates strings that cross the boundary. Need to be careful about
dangling pointers and ensure proper cleanup.

**Debugging**: A bug could be in JSX source, bundled JS, QuickJS evaluation,
FFI bridge, command interpretation, layout, or painting. That's a lot of layers.
Mitigate with: command logging, a devtools overlay (draw layout rects), and
React DevTools support (react-reconciler supports injection).

**QuickJS compilation**: Need to compile QuickJS as a shared library for each
target platform (Linux, macOS, Windows). Straightforward (`make libquickjs.so`)
but adds a build step and platform matrix.

## Comparison: The Three Approaches

| Approach | Authoring | Ecosystem | Performance | Complexity |
|----------|-----------|-----------|-------------|------------|
| **Reactor** (pure Lua) | Lua tables | None | Best (native) | Low |
| **TSTL/Armastus** (transpile) | TSX → Lua | Partial | Good | Medium |
| **react-love** (embedded JS) | Real JSX | Full npm | Good enough | High |

For engAIge — where you're already building a fake internet with hundreds of
interconnected systems — the embedded approach makes the most sense. The UI
complexity is high enough that you'd be constantly fighting a Lua reimplementation's
edge cases. With real React, the edge cases are already solved.

## Prior Art

This exact architecture exists and works in production:

- **React Native**: Hermes/JSC → bridge → native views
- **react-three-fiber**: React → Three.js scene graph mutations
- **Ink**: React → terminal ANSI escape codes
- **react-hardware**: React → Johnny-Five → actual hardware I/O
- **react-blessed**: React → blessed terminal widgets
- **Figma**: QuickJS running plugin code inside a native app (same embedding pattern)

We're just adding Love2D to this list.
