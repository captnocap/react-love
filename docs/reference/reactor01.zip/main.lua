--[[
  main.lua — Love2D entry point for react-love
  
  This is the integration layer. It:
  1. Boots QuickJS with the bundled React app
  2. Each frame: ticks JS, drains commands, updates the retained tree
  3. Runs flexbox layout when tree changes
  4. Paints the tree via Love2D draw calls
  5. Routes input events back to JS
  
  The developer never touches this file. They write JSX components,
  run `npm run build`, and this file loads the output.
]]

local Bridge = require("quickjs_bridge")
local json = require("json")

-- ────────────────────────────────────────────────────────
-- Retained Element Tree
-- The "DOM equivalent" — what the layout engine and painter work on.
-- Commands from React mutate this tree.
-- ────────────────────────────────────────────────────────

local nodes = {}       -- id -> node
local rootChildren = {} -- ordered root children
local treeDirty = true

local function applyCommands(commands)
  for _, cmd in ipairs(commands) do
    local op = cmd.op
    
    if op == "CREATE" then
      nodes[cmd.id] = {
        id = cmd.id,
        type = cmd.type,
        props = cmd.props or {},
        style = (cmd.props and cmd.props.style) or {},
        hasHandlers = cmd.hasHandlers or false,
        children = {},
        parent = nil,
        computed = nil,  -- filled by layout
      }
      treeDirty = true
      
    elseif op == "CREATE_TEXT" then
      nodes[cmd.id] = {
        id = cmd.id,
        type = "__TEXT__",
        text = cmd.text,
        style = {},
        children = {},
        parent = nil,
        computed = nil,
      }
      treeDirty = true
      
    elseif op == "APPEND" then
      local parent = nodes[cmd.parentId]
      local child = nodes[cmd.childId]
      if parent and child then
        child.parent = parent
        parent.children[#parent.children + 1] = child
        treeDirty = true
      end
      
    elseif op == "APPEND_TO_ROOT" then
      local child = nodes[cmd.childId]
      if child then
        rootChildren[#rootChildren + 1] = child
        treeDirty = true
      end
      
    elseif op == "UPDATE" then
      local node = nodes[cmd.id]
      if node and cmd.props then
        for k, v in pairs(cmd.props) do
          node.props[k] = v
          if k == "style" then node.style = v end
        end
        treeDirty = true
      end
      
    elseif op == "UPDATE_TEXT" then
      local node = nodes[cmd.id]
      if node then
        node.text = cmd.text
        treeDirty = true
      end
      
    elseif op == "REMOVE" then
      local parent = nodes[cmd.parentId]
      if parent then
        for i, c in ipairs(parent.children) do
          if c.id == cmd.childId then
            table.remove(parent.children, i)
            break
          end
        end
      end
      -- recursively clean up
      local function cleanup(id)
        local n = nodes[id]
        if n then
          for _, c in ipairs(n.children) do cleanup(c.id) end
          nodes[id] = nil
        end
      end
      cleanup(cmd.childId)
      treeDirty = true
      
    elseif op == "REMOVE_FROM_ROOT" then
      for i, c in ipairs(rootChildren) do
        if c.id == cmd.childId then
          table.remove(rootChildren, i)
          break
        end
      end
      nodes[cmd.childId] = nil
      treeDirty = true
      
    elseif op == "INSERT_BEFORE" then
      local parent = nodes[cmd.parentId]
      local child = nodes[cmd.childId]
      if parent and child then
        child.parent = parent
        for i, c in ipairs(parent.children) do
          if c.id == cmd.beforeId then
            table.insert(parent.children, i, child)
            treeDirty = true
            break
          end
        end
      end
      
    elseif op == "INSERT_BEFORE_ROOT" then
      local child = nodes[cmd.childId]
      if child then
        for i, c in ipairs(rootChildren) do
          if c.id == cmd.beforeId then
            table.insert(rootChildren, i, child)
            treeDirty = true
            break
          end
        end
      end
    end
  end
end

local function getTree()
  if #rootChildren == 1 then return rootChildren[1] end
  return {
    id = 0,
    type = "View",
    style = { width = "100%", height = "100%" },
    children = rootChildren,
    props = {},
    computed = nil,
  }
end

-- ────────────────────────────────────────────────────────
-- Layout Engine (flexbox)
-- Simplified from reactor.lua — computes (x, y, w, h) for every node
-- ────────────────────────────────────────────────────────

local function resolveUnit(value, parentSize)
  if value == nil then return nil end
  if type(value) == "number" then return value end
  if type(value) ~= "string" then return nil end
  
  local num, unit = value:match("^([%d%.]+)(.*)$")
  num = tonumber(num)
  if not num then return nil end
  
  if unit == "%" then return (num / 100) * (parentSize or 0)
  elseif unit == "vw" then return (num / 100) * love.graphics.getWidth()
  elseif unit == "vh" then return (num / 100) * love.graphics.getHeight()
  else return num end
end

local function layoutNode(node, px, py, pw, ph)
  if not node then return end
  local s = node.style or {}
  
  local w = resolveUnit(s.width, pw) or pw or 0
  local h = resolveUnit(s.height, ph)
  
  local pad = resolveUnit(s.padding, w) or 0
  local padL = resolveUnit(s.paddingLeft, w) or pad
  local padR = resolveUnit(s.paddingRight, w) or pad
  local padT = resolveUnit(s.paddingTop, h) or pad
  local padB = resolveUnit(s.paddingBottom, h) or pad
  
  local mar = resolveUnit(s.margin, pw) or 0
  local marL = resolveUnit(s.marginLeft, pw) or mar
  local marT = resolveUnit(s.marginTop, ph) or mar
  
  local x = px + marL
  local y = py + marT
  local innerW = w - padL - padR
  local innerH = (h or 9999) - padT - padB
  
  local isRow = s.flexDirection == "row"
  local gap = resolveUnit(s.gap, isRow and innerW or innerH) or 0
  local justify = s.justifyContent or "start"
  local align = s.alignItems or "start"
  
  -- Measure children
  local children = node.children or {}
  local totalMain = 0
  local totalFlex = 0
  local childInfos = {}
  
  for i, child in ipairs(children) do
    local cs = child.style or {}
    local cw = resolveUnit(cs.width, innerW)
    local ch = resolveUnit(cs.height, innerH)
    local grow = cs.flexGrow or 0
    local basis = isRow and (cw or 0) or (ch or 0)
    
    childInfos[i] = { w = cw, h = ch, grow = grow, basis = basis }
    if grow > 0 then totalFlex = totalFlex + grow
    else totalMain = totalMain + basis end
  end
  
  local totalGaps = math.max(0, #children - 1) * gap
  local avail = (isRow and innerW or innerH) - totalMain - totalGaps
  
  -- Distribute flex
  if totalFlex > 0 and avail > 0 then
    for _, ci in ipairs(childInfos) do
      if ci.grow > 0 then ci.basis = (ci.grow / totalFlex) * avail end
    end
  end
  
  -- Justify
  local usedMain = 0
  for _, ci in ipairs(childInfos) do usedMain = usedMain + ci.basis end
  local freeMain = (isRow and innerW or innerH) - usedMain - totalGaps
  local mainOff, extraGap = 0, 0
  
  if justify == "center" then mainOff = freeMain / 2
  elseif justify == "end" then mainOff = freeMain
  elseif justify == "space-between" and #children > 1 then extraGap = freeMain / (#children - 1)
  elseif justify == "space-around" and #children > 0 then
    extraGap = freeMain / #children; mainOff = extraGap / 2
  elseif justify == "space-evenly" and #children > 0 then
    extraGap = freeMain / (#children + 1); mainOff = extraGap
  end
  
  -- Position children
  local cursor = mainOff
  local contentEnd = 0
  
  for i, child in ipairs(children) do
    local ci = childInfos[i]
    local cx, cy, cw_final, ch_final
    
    if isRow then
      cx = x + padL + cursor
      cw_final = ci.basis
      ch_final = ci.h or innerH
      if align == "center" then cy = y + padT + (innerH - ch_final) / 2
      elseif align == "end" then cy = y + padT + innerH - ch_final
      elseif align == "stretch" then cy = y + padT; ch_final = innerH
      else cy = y + padT end
    else
      cy = y + padT + cursor
      ch_final = ci.basis
      cw_final = ci.w or innerW
      if align == "center" then cx = x + padL + (innerW - cw_final) / 2
      elseif align == "end" then cx = x + padL + innerW - cw_final
      elseif align == "stretch" then cx = x + padL; cw_final = innerW
      else cx = x + padL end
    end
    
    child.computed = { x = cx, y = cy, w = cw_final, h = ch_final }
    layoutNode(child, cx, cy, cw_final, ch_final)
    
    cursor = cursor + ci.basis + gap + extraGap
    local childEnd = isRow and (cx - x + cw_final) or (cy - y + ch_final)
    if childEnd > contentEnd then contentEnd = childEnd end
  end
  
  if h == nil then h = contentEnd + padT + padB end
  node.computed = { x = x, y = y, w = w, h = h }
end

-- ────────────────────────────────────────────────────────
-- Painter (Love2D draw calls)
-- ────────────────────────────────────────────────────────

local function setColor(c)
  if not c then return end
  if type(c) == "string" then
    -- parse hex color like "#ff00ff"
    local r, g, b = c:match("#(%x%x)(%x%x)(%x%x)")
    if r then
      love.graphics.setColor(tonumber(r, 16)/255, tonumber(g, 16)/255, tonumber(b, 16)/255, 1)
    end
  elseif type(c) == "table" then
    love.graphics.setColor(c[1] or 0, c[2] or 0, c[3] or 0, c[4] or 1)
  end
end

local function paintNode(node)
  if not node or not node.computed then return end
  local c = node.computed
  local s = node.style or {}
  
  -- Clipping
  local clipping = s.overflow == "hidden"
  if clipping then love.graphics.setScissor(c.x, c.y, c.w, c.h) end
  
  if node.type == "View" or node.type == "box" then
    if s.backgroundColor then
      setColor(s.backgroundColor)
      local r = s.borderRadius or 0
      love.graphics.rectangle("fill", c.x, c.y, c.w, c.h, r, r)
    end
    if s.borderWidth and s.borderWidth > 0 then
      setColor(s.borderColor or { 0.5, 0.5, 0.5, 1 })
      love.graphics.setLineWidth(s.borderWidth)
      local r = s.borderRadius or 0
      love.graphics.rectangle("line", c.x, c.y, c.w, c.h, r, r)
    end
    
  elseif node.type == "Text" or node.type == "__TEXT__" then
    setColor(s.color or { 1, 1, 1, 1 })
    local text = node.text or (node.props and node.props.children) or ""
    if type(text) == "table" then text = table.concat(text) end
    local align = s.textAlign or "left"
    love.graphics.printf(tostring(text), c.x, c.y, c.w, align)
    
  elseif node.type == "Image" then
    -- Image loading would go through Love2D's image cache
    love.graphics.setColor(1, 1, 1, s.opacity or 1)
    -- node.props.src -> love.graphics.newImage(src)
    -- For now, draw a placeholder
    love.graphics.rectangle("line", c.x, c.y, c.w, c.h)
  end
  
  -- Paint children
  for _, child in ipairs(node.children or {}) do
    paintNode(child)
  end
  
  if clipping then love.graphics.setScissor() end
end

-- ────────────────────────────────────────────────────────
-- Hit Testing (for routing mouse events back to JS)
-- ────────────────────────────────────────────────────────

local function hitTest(node, mx, my)
  if not node or not node.computed then return nil end
  local c = node.computed
  
  if mx < c.x or mx > c.x + c.w or my < c.y or my > c.y + c.h then
    return nil
  end
  
  -- Check children in reverse (topmost first)
  local children = node.children or {}
  for i = #children, 1, -1 do
    local hit = hitTest(children[i], mx, my)
    if hit then return hit end
  end
  
  -- Return this node if it has event handlers registered in JS
  if node.hasHandlers then return node end
  return nil
end

-- ────────────────────────────────────────────────────────
-- Love2D Lifecycle
-- ────────────────────────────────────────────────────────

local bridge
local hoveredNode = nil

function love.load()
  love.window.setTitle("react-love")
  love.window.setMode(1024, 768, { resizable = true, vsync = 1 })
  
  -- Boot the JS runtime
  bridge = Bridge.new("lib/libquickjs")
  
  -- Load the bundled React app
  local bundleJS = love.filesystem.read("bundle.js")
  if not bundleJS then
    error("bundle.js not found — run `npm run build` first")
  end
  
  bridge:eval(bundleJS, "bundle.js")
  print("[react-love] React app loaded")
end

function love.update(dt)
  -- 1. Tick JS timers + microtasks
  bridge:tick()
  
  -- 2. Tell JS to process any pending input events
  bridge:eval("if (globalThis._pollAndDispatchEvents) _pollAndDispatchEvents();")
  
  -- 3. Tick again (event handlers may have triggered state updates → renders → commands)
  bridge:tick()
  
  -- 4. Drain mutation commands from JS → apply to retained tree
  local commands = bridge:drainCommands()
  if #commands > 0 then
    applyCommands(commands)
  end
  
  -- 5. Relayout if tree changed or window resized
  if treeDirty then
    local tree = getTree()
    if tree then
      local w = love.graphics.getWidth()
      local h = love.graphics.getHeight()
      layoutNode(tree, 0, 0, w, h)
    end
    treeDirty = false
  end
end

function love.draw()
  love.graphics.clear(0.05, 0.05, 0.08, 1)
  
  local tree = getTree()
  if tree then
    paintNode(tree)
  end
  
  love.graphics.setColor(1, 1, 1, 1)
  
  -- Debug: show node count + FPS
  love.graphics.print(
    string.format("nodes: %d  fps: %d", tableSize(nodes), love.timer.getFPS()),
    4, love.graphics.getHeight() - 20
  )
end

function love.mousepressed(x, y, button)
  local tree = getTree()
  if not tree then return end
  local hit = hitTest(tree, x, y)
  if hit then
    bridge:pushEvent({
      type = "click",
      targetId = hit.id,
      x = x, y = y, button = button,
    })
  end
end

function love.mousereleased(x, y, button)
  local tree = getTree()
  if not tree then return end
  local hit = hitTest(tree, x, y)
  if hit then
    bridge:pushEvent({
      type = "release",
      targetId = hit.id,
      x = x, y = y, button = button,
    })
  end
end

function love.mousemoved(x, y, dx, dy)
  local tree = getTree()
  if not tree then return end
  local hit = hitTest(tree, x, y)
  
  if hit ~= hoveredNode then
    if hoveredNode then
      bridge:pushEvent({ type = "pointerLeave", targetId = hoveredNode.id, x = x, y = y })
    end
    if hit then
      bridge:pushEvent({ type = "pointerEnter", targetId = hit.id, x = x, y = y })
    end
    hoveredNode = hit
  end
end

function love.resize(w, h)
  treeDirty = true
end

function love.quit()
  if bridge then bridge:destroy() end
end

-- Util
function tableSize(t)
  local count = 0
  for _ in pairs(t) do count = count + 1 end
  return count
end
