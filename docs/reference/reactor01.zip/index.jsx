// src/index.jsx
// Entry point: real React, real JSX, real hooks.
// Bundled by esbuild, evaluated by QuickJS, rendered by Love2D.

import React, { useState, useEffect, useMemo, useCallback, createContext, useContext } from 'react';
import { render } from './renderer';

// ────────────────────────────────────────────────────────
// Theme context — works exactly like React on the web
// ────────────────────────────────────────────────────────

const ThemeContext = createContext({
  primary: [0.35, 0.55, 1.0, 1],
  surface: [0.12, 0.12, 0.18, 1],
  surfaceHover: [0.18, 0.18, 0.25, 1],
  text: [0.92, 0.92, 0.96, 1],
  textDim: [0.55, 0.55, 0.65, 1],
  danger: [0.85, 0.25, 0.25, 1],
  success: [0.3, 0.75, 0.35, 1],
  radius: 8,
});

function useTheme() {
  return useContext(ThemeContext);
}

// ────────────────────────────────────────────────────────
// Primitive components
// These map to Love2D element types on the Lua side
// ────────────────────────────────────────────────────────

// View  = flexbox container (renders as box with background, border, etc.)
// Text  = text rendering (Love2D printf)
// Image = sprite/image rendering

// They're just strings — React resolves them as host component types:
//   <View> → createInstance("View", props)
//   <Text> → createInstance("Text", props)

// ────────────────────────────────────────────────────────
// HealthBar component
// ────────────────────────────────────────────────────────

function HealthBar({ value, max = 100 }) {
  const theme = useTheme();
  const pct = Math.max(0, Math.min(1, value / max));
  
  // Color shifts from green → yellow → red
  const barColor = pct > 0.6 
    ? theme.success
    : pct > 0.3
      ? [0.9, 0.75, 0.2, 1]
      : theme.danger;
  
  return (
    <View style={{
      width: 200,
      height: 24,
      backgroundColor: [0.08, 0.08, 0.12, 1],
      borderRadius: 12,
      borderWidth: 1,
      borderColor: [0.25, 0.25, 0.35, 1],
      overflow: 'hidden',
    }}>
      {/* Fill bar */}
      <View style={{
        width: `${pct * 100}%`,
        height: '100%',
        backgroundColor: barColor,
        borderRadius: 12,
      }} />
      {/* Label overlay */}
      <Text style={{
        position: 'absolute',
        width: 200,
        textAlign: 'center',
        color: theme.text,
        fontSize: 12,
      }}>
        {`${Math.round(value)} / ${max}`}
      </Text>
    </View>
  );
}

// ────────────────────────────────────────────────────────
// Inventory slot
// ────────────────────────────────────────────────────────

function InventorySlot({ item, selected, onSelect }) {
  const theme = useTheme();
  const [hovered, setHovered] = useState(false);
  
  const bgColor = selected 
    ? theme.primary 
    : hovered 
      ? theme.surfaceHover 
      : theme.surface;
  
  return (
    <View
      style={{
        width: 64,
        height: 64,
        backgroundColor: bgColor,
        borderRadius: theme.radius,
        borderWidth: selected ? 2 : 1,
        borderColor: selected ? theme.primary : [0.25, 0.25, 0.35, 1],
        justifyContent: 'center',
        alignItems: 'center',
      }}
      onClick={() => onSelect(item)}
      onPointerEnter={() => setHovered(true)}
      onPointerLeave={() => setHovered(false)}
    >
      {item ? (
        <>
          <Image 
            src={item.icon}
            style={{ width: 40, height: 40 }}
          />
          {item.count > 1 && (
            <Text style={{
              position: 'absolute',
              bottom: 2,
              right: 4,
              color: theme.text,
              fontSize: 10,
            }}>
              {item.count}
            </Text>
          )}
        </>
      ) : null}
    </View>
  );
}

// ────────────────────────────────────────────────────────
// Tooltip — conditional rendering, just like web React
// ────────────────────────────────────────────────────────

function Tooltip({ text, visible }) {
  if (!visible) return null;
  const theme = useTheme();
  
  return (
    <View style={{
      backgroundColor: [0.05, 0.05, 0.08, 0.95],
      borderRadius: 6,
      padding: 8,
      paddingLeft: 12,
      paddingRight: 12,
      borderWidth: 1,
      borderColor: [0.3, 0.3, 0.4, 1],
    }}>
      <Text style={{ color: theme.text, fontSize: 12 }}>{text}</Text>
    </View>
  );
}

// ────────────────────────────────────────────────────────
// Game HUD — composes everything
// ────────────────────────────────────────────────────────

function HUD() {
  // In a real game, these would come from a bridge to Lua game state
  const [health, setHealth] = useState(73);
  const [mana, setMana] = useState(45);
  const [score, setScore] = useState(12450);
  const [selectedSlot, setSelectedSlot] = useState(null);
  
  // Fake inventory
  const inventory = useMemo(() => [
    { id: 1, name: 'Sword', icon: 'sword.png', count: 1 },
    { id: 2, name: 'Health Potion', icon: 'potion_red.png', count: 5 },
    { id: 3, name: 'Mana Crystal', icon: 'crystal.png', count: 3 },
    null, null, null, null, null, // empty slots
  ], []);
  
  // Simulate health drain for demo
  useEffect(() => {
    // __hostRequestTimer would be exposed by the Lua bridge
    // For now this shows the pattern
    const interval = setInterval(() => {
      setHealth(h => Math.max(0, h - 1));
    }, 2000);
    return () => clearInterval(interval);
  }, []);
  
  const theme = useTheme();
  
  return (
    <View style={{
      width: '100%',
      height: '100%',
      padding: 16,
      justifyContent: 'space-between',
    }}>
      {/* Top bar: health, mana, score */}
      <View style={{
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'start',
      }}>
        <View style={{ gap: 8 }}>
          <HealthBar value={health} max={100} />
          <HealthBar value={mana} max={100} />
        </View>
        
        <View style={{
          backgroundColor: theme.surface,
          borderRadius: theme.radius,
          padding: 12,
          paddingLeft: 20,
          paddingRight: 20,
        }}>
          <Text style={{ color: [1, 0.85, 0.3, 1], fontSize: 18 }}>
            {score.toLocaleString()}
          </Text>
        </View>
      </View>
      
      {/* Bottom bar: inventory hotbar */}
      <View style={{
        flexDirection: 'row',
        justifyContent: 'center',
        gap: 6,
      }}>
        {inventory.map((item, i) => (
          <InventorySlot
            key={i}
            item={item}
            selected={selectedSlot === i}
            onSelect={() => setSelectedSlot(i)}
          />
        ))}
      </View>
      
      {/* Tooltip for selected item */}
      <Tooltip
        text={selectedSlot !== null && inventory[selectedSlot]?.name || ''}
        visible={selectedSlot !== null && inventory[selectedSlot] !== null}
      />
    </View>
  );
}

// ────────────────────────────────────────────────────────
// App root
// ────────────────────────────────────────────────────────

function App() {
  return (
    <ThemeContext.Provider value={{
      primary: [0.35, 0.55, 1.0, 1],
      surface: [0.12, 0.12, 0.18, 1],
      surfaceHover: [0.18, 0.18, 0.25, 1],
      text: [0.92, 0.92, 0.96, 1],
      textDim: [0.55, 0.55, 0.65, 1],
      danger: [0.85, 0.25, 0.25, 1],
      success: [0.3, 0.75, 0.35, 1],
      radius: 8,
    }}>
      <HUD />
    </ThemeContext.Provider>
  );
}

// ────────────────────────────────────────────────────────
// Mount
// ────────────────────────────────────────────────────────

render(<App />);
