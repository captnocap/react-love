// react-love-renderer.js
// Custom React renderer targeting Love2D via QuickJS bridge
//
// This is the exact same pattern as react-dom, react-native, ink, react-three-fiber.
// React handles: components, hooks, state, reconciliation, diffing.
// We handle: creating/updating/removing Love2D elements via command buffer.

import Reconciler from 'react-reconciler';

// ────────────────────────────────────────────────────────
// Command buffer: accumulates mutations, flushes to Lua
// ────────────────────────────────────────────────────────

let nodeIdCounter = 0;
let pendingCommands = [];

function emit(cmd) {
  pendingCommands.push(cmd);
}

function flushToHost() {
  if (pendingCommands.length === 0) return;
  // __hostFlush is a C function exposed by the Lua FFI bridge
  globalThis.__hostFlush(JSON.stringify(pendingCommands));
  pendingCommands = [];
}

// ────────────────────────────────────────────────────────
// Event handler registry
// React event handlers (onClick, onPointerEnter, etc.) live in JS.
// The Lua side does hit-testing and sends events here by node ID.
// ────────────────────────────────────────────────────────

const handlerRegistry = new Map(); // nodeId -> { onClick: fn, ... }

function extractHandlers(props) {
  const handlers = {};
  const cleanProps = {};
  for (const key in props) {
    if (key.startsWith('on') && typeof props[key] === 'function') {
      handlers[key] = props[key];
    } else if (key !== 'children') {
      cleanProps[key] = props[key];
    }
  }
  return { handlers, cleanProps };
}

// Called from Lua via bridge each frame
globalThis._pollAndDispatchEvents = function() {
  let eventsJson;
  try {
    eventsJson = globalThis.__hostGetEvents();
  } catch (e) {
    return;
  }
  
  if (!eventsJson || eventsJson === '[]') return;
  
  const events = JSON.parse(eventsJson);
  for (const event of events) {
    const handlers = handlerRegistry.get(event.targetId);
    if (!handlers) continue;
    
    // Map event types: "click" -> "onClick", "pointerEnter" -> "onPointerEnter"
    const handlerName = 'on' + event.type.charAt(0).toUpperCase() + event.type.slice(1);
    if (handlers[handlerName]) {
      handlers[handlerName](event);
    }
  }
};

// ────────────────────────────────────────────────────────
// Host Config: the interface between React and Love2D
// ────────────────────────────────────────────────────────

const hostConfig = {
  supportsMutation: true,
  supportsPersistence: false,
  supportsHydration: false,

  // ─── Creating instances ───
  
  createInstance(type, props, rootContainer, hostContext, fiber) {
    const id = ++nodeIdCounter;
    const { handlers, cleanProps } = extractHandlers(props);
    
    // Register event handlers on JS side
    if (Object.keys(handlers).length > 0) {
      handlerRegistry.set(id, handlers);
    }
    
    emit({
      op: 'CREATE',
      id,
      type,
      props: cleanProps,
      // Tell Lua if this node has handlers (for hit-test optimization)
      hasHandlers: Object.keys(handlers).length > 0,
    });
    
    return { id, type, props: cleanProps, handlers, children: [] };
  },

  createTextInstance(text, rootContainer, hostContext, fiber) {
    const id = ++nodeIdCounter;
    emit({ op: 'CREATE_TEXT', id, text });
    return { id, type: '__TEXT__', text, children: [] };
  },

  // ─── Tree assembly ───
  
  appendInitialChild(parent, child) {
    parent.children.push(child);
    emit({ op: 'APPEND', parentId: parent.id, childId: child.id });
  },

  appendChild(parent, child) {
    parent.children.push(child);
    emit({ op: 'APPEND', parentId: parent.id, childId: child.id });
  },

  appendChildToContainer(container, child) {
    emit({ op: 'APPEND_TO_ROOT', childId: child.id });
  },

  // ─── Updates ───

  prepareUpdate(instance, type, oldProps, newProps) {
    const { handlers: oldH, cleanProps: oldClean } = extractHandlers(oldProps);
    const { handlers: newH, cleanProps: newClean } = extractHandlers(newProps);
    
    let propUpdates = null;
    let handlerUpdates = null;
    
    // Diff props
    for (const key in newClean) {
      if (!shallowEqual(newClean[key], oldClean[key])) {
        if (!propUpdates) propUpdates = {};
        propUpdates[key] = newClean[key];
      }
    }
    for (const key in oldClean) {
      if (!(key in newClean)) {
        if (!propUpdates) propUpdates = {};
        propUpdates[key] = null;  // signal removal
      }
    }
    
    // Diff handlers
    for (const key in newH) {
      if (newH[key] !== oldH[key]) {
        if (!handlerUpdates) handlerUpdates = {};
        handlerUpdates[key] = newH[key];
      }
    }
    
    if (propUpdates || handlerUpdates) {
      return { propUpdates, handlerUpdates };
    }
    return null;
  },

  commitUpdate(instance, updatePayload, type, oldProps, newProps) {
    if (updatePayload.propUpdates) {
      Object.assign(instance.props, updatePayload.propUpdates);
      emit({ op: 'UPDATE', id: instance.id, props: updatePayload.propUpdates });
    }
    if (updatePayload.handlerUpdates) {
      Object.assign(instance.handlers, updatePayload.handlerUpdates);
      handlerRegistry.set(instance.id, instance.handlers);
    }
  },

  commitTextUpdate(textInstance, oldText, newText) {
    textInstance.text = newText;
    emit({ op: 'UPDATE_TEXT', id: textInstance.id, text: newText });
  },

  // ─── Removal ───

  removeChild(parent, child) {
    const idx = parent.children.indexOf(child);
    if (idx !== -1) parent.children.splice(idx, 1);
    emit({ op: 'REMOVE', parentId: parent.id, childId: child.id });
    handlerRegistry.delete(child.id);
  },

  removeChildFromContainer(container, child) {
    emit({ op: 'REMOVE_FROM_ROOT', childId: child.id });
    handlerRegistry.delete(child.id);
  },

  // ─── Reordering ───

  insertBefore(parent, child, before) {
    const idx = parent.children.indexOf(before);
    if (idx !== -1) parent.children.splice(idx, 0, child);
    emit({ op: 'INSERT_BEFORE', parentId: parent.id, childId: child.id, beforeId: before.id });
  },

  insertInContainerBefore(container, child, before) {
    emit({ op: 'INSERT_BEFORE_ROOT', childId: child.id, beforeId: before.id });
  },

  // ─── Commit lifecycle ───
  
  prepareForCommit() { return null; },
  
  resetAfterCommit() {
    // Every React commit flushes all accumulated commands to Lua
    flushToHost();
  },

  // ─── Static config ───

  finalizeInitialChildren() { return false; },
  getPublicInstance(instance) { return instance; },
  shouldSetTextContent(type, props) { return false; },
  getRootHostContext() { return {}; },
  getChildHostContext(parentContext) { return parentContext; },
  clearContainer() {},
  preparePortalMount() {},
  
  // Timing
  scheduleTimeout: setTimeout,
  cancelTimeout: clearTimeout,
  noTimeout: -1,
  
  // Microtasks (QuickJS supports queueMicrotask)
  supportsMicrotasks: true,
  scheduleMicrotask: typeof queueMicrotask === 'function' ? queueMicrotask : (fn) => setTimeout(fn, 0),
  
  isPrimaryRenderer: true,
  
  getCurrentEventPriority() {
    return 0b0000000000000000000000000010000; // DefaultEventPriority
  },
  
  getInstanceFromNode() { return null; },
  beforeActiveInstanceBlur() {},
  afterActiveInstanceBlur() {},
  prepareScopeUpdate() {},
  getInstanceFromScope() { return null; },
  detachDeletedInstance(instance) {
    handlerRegistry.delete(instance.id);
  },
};

// Shallow comparison for style objects
function shallowEqual(a, b) {
  if (a === b) return true;
  if (typeof a !== typeof b) return false;
  if (typeof a !== 'object' || a === null || b === null) return false;
  const keysA = Object.keys(a);
  const keysB = Object.keys(b);
  if (keysA.length !== keysB.length) return false;
  for (const key of keysA) {
    if (a[key] !== b[key]) return false;
  }
  return true;
}

// ────────────────────────────────────────────────────────
// Create the reconciler and expose the public API
// ────────────────────────────────────────────────────────

const reconciler = Reconciler(hostConfig);
const roots = new Map();

export function render(element, container) {
  container = container || { id: 0 };
  let root = roots.get(container);
  if (!root) {
    root = reconciler.createContainer(
      container,    // containerInfo
      0,            // tag (LegacyRoot)
      null,         // hydrationCallbacks
      false,        // isStrictMode
      null,         // concurrentUpdatesByDefaultOverride
      '',           // identifierPrefix
      null,         // onUncaughtError
      null,         // onCaughtError
    );
    roots.set(container, root);
  }
  reconciler.updateContainer(element, root, null, null);
  return container;
}

export function unmount(container) {
  const root = roots.get(container);
  if (root) {
    reconciler.updateContainer(null, root, null, null);
    roots.delete(container);
  }
}

// ────────────────────────────────────────────────────────
// Expose to global scope (QuickJS doesn't have module system by default)
// esbuild wraps this in an IIFE that assigns to globalThis.ReactLove
// ────────────────────────────────────────────────────────

export { React };
