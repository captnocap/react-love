--[[
  Reactor - React-style declarative UI for Love2D
  
  Architecture:
    createElement -> VNode tree (virtual DOM)
    render()      -> schedules reconciliation
    reconcile()   -> diffs old/new VNode trees, produces Fiber work units  
    commit()      -> applies changes to the retained element tree
    layout()      -> flexbox pass over retained elements (borrowed from FlexLöve's approach)
    paint()       -> Love2D draw calls from computed layout
    
  Key insight: React assumes a retained DOM it owns. Love2D gives you a draw() callback.
  We bridge this by maintaining our own retained element tree that maps VNodes -> LayoutNodes,
  then painting from computed layout each frame. State changes trigger re-reconciliation,
  not re-rendering from scratch.
]]

local Reactor = {}
Reactor.__index = Reactor

-- ============================================================================
-- SECTION 1: Virtual Node (VNode) Creation
-- This is your JSX equivalent. h() builds a description of what you want,
-- not the thing itself.
-- ============================================================================

local COMPONENT = "COMPONENT"
local ELEMENT   = "ELEMENT"
local TEXT       = "TEXT"
local FRAGMENT  = "FRAGMENT"

---@param type string|function  -- "box", "text", "image", or a component function
---@param props table|nil
---@param ... any               -- children (VNodes, strings, numbers, or tables of them)
function Reactor.h(type, props, ...)
  props = props or {}
  local children = {}
  
  -- flatten children, coerce primitives to text nodes
  local function collect(item)
    if item == nil or item == false then return end
    if type == "table" and item.__vnode then
      children[#children + 1] = item
    elseif _G.type(item) == "table" and not item.__vnode then
      -- array of children
      for _, child in ipairs(item) do collect(child) end
    elseif _G.type(item) == "string" or _G.type(item) == "number" then
      children[#children + 1] = {
        __vnode = true,
        kind = TEXT,
        props = { value = tostring(item) },
        children = {},
        key = nil,
      }
    elseif _G.type(item) == "table" and item.__vnode then
      children[#children + 1] = item
    end
  end
  
  local args = { ... }
  for _, arg in ipairs(args) do collect(arg) end
  
  -- extract key from props
  local key = props.key
  props.key = nil
  
  local kind
  if _G.type(type) == "function" then
    kind = COMPONENT
  elseif type == "" or type == nil then
    kind = FRAGMENT
  else
    kind = ELEMENT
  end
  
  return {
    __vnode = true,
    kind = kind,
    type = type,
    props = props,
    children = children,
    key = key,
  }
end

-- shorthand
local h = Reactor.h

-- Fragment constructor
function Reactor.Fragment(props, ...)
  return h("", props, ...)
end

-- ============================================================================
-- SECTION 2: Hooks Runtime
-- Hooks are stored per-fiber. The "current fiber" is set during render and
-- hooks index into that fiber's hook slots sequentially (same as React).
-- ============================================================================

local HookState = {
  currentFiber = nil,
  hookIndex = 0,
  pendingEffects = {},    -- effects to run after commit
  cleanupEffects = {},    -- cleanup functions from previous effects
}

--- useState: returns [value, setter]. Setter triggers re-render of this component.
function Reactor.useState(initial)
  local fiber = HookState.currentFiber
  assert(fiber, "useState called outside of component render")
  
  local idx = HookState.hookIndex
  HookState.hookIndex = idx + 1
  
  -- initialize on first render
  if fiber.hooks[idx] == nil then
    local val = initial
    if _G.type(initial) == "function" then val = initial() end
    fiber.hooks[idx] = { state = val }
  end
  
  local hook = fiber.hooks[idx]
  local capturedFiber = fiber  -- close over for setter
  
  local function setState(nextValue)
    local prev = hook.state
    if _G.type(nextValue) == "function" then
      nextValue = nextValue(prev)
    end
    if prev ~= nextValue then
      hook.state = nextValue
      capturedFiber.dirty = true
      Reactor._scheduleUpdate()
    end
  end
  
  return hook.state, setState
end

--- useEffect: runs side effects after commit. Deps array controls when it re-runs.
function Reactor.useEffect(callback, deps)
  local fiber = HookState.currentFiber
  assert(fiber, "useEffect called outside of component render")
  
  local idx = HookState.hookIndex
  HookState.hookIndex = idx + 1
  
  local prevHook = fiber.hooks[idx]
  local shouldRun = true
  
  if prevHook and deps then
    -- compare deps
    shouldRun = false
    local prevDeps = prevHook.deps
    if prevDeps == nil or #prevDeps ~= #deps then
      shouldRun = true
    else
      for i = 1, #deps do
        if deps[i] ~= prevDeps[i] then
          shouldRun = true
          break
        end
      end
    end
  end
  
  fiber.hooks[idx] = { deps = deps, cleanup = prevHook and prevHook.cleanup }
  
  if shouldRun then
    -- queue effect to run after commit phase
    HookState.pendingEffects[#HookState.pendingEffects + 1] = {
      fiber = fiber,
      hookIndex = idx,
      callback = callback,
    }
  end
end

--- useMemo: memoize expensive computations
function Reactor.useMemo(factory, deps)
  local fiber = HookState.currentFiber
  assert(fiber, "useMemo called outside of component render")
  
  local idx = HookState.hookIndex
  HookState.hookIndex = idx + 1
  
  local prevHook = fiber.hooks[idx]
  
  if prevHook and deps then
    local prevDeps = prevHook.deps
    local same = prevDeps ~= nil and #prevDeps == #deps
    if same then
      for i = 1, #deps do
        if deps[i] ~= prevDeps[i] then same = false; break end
      end
    end
    if same then return prevHook.value end
  end
  
  local value = factory()
  fiber.hooks[idx] = { value = value, deps = deps }
  return value
end

--- useCallback: memoize a function reference
function Reactor.useCallback(fn, deps)
  return Reactor.useMemo(function() return fn end, deps)
end

--- useRef: persistent mutable container that doesn't trigger re-renders
function Reactor.useRef(initial)
  local fiber = HookState.currentFiber
  assert(fiber, "useRef called outside of component render")
  
  local idx = HookState.hookIndex
  HookState.hookIndex = idx + 1
  
  if fiber.hooks[idx] == nil then
    fiber.hooks[idx] = { current = initial }
  end
  return fiber.hooks[idx]
end

--- useContext: read from a context provider above in the tree
function Reactor.useContext(context)
  local fiber = HookState.currentFiber
  assert(fiber, "useContext called outside of component render")
  
  -- walk up the fiber tree to find a provider for this context
  local parent = fiber.parent
  while parent do
    if parent.contextProviders and parent.contextProviders[context] then
      return parent.contextProviders[context]
    end
    parent = parent.parent
  end
  return context._defaultValue
end

--- createContext
function Reactor.createContext(defaultValue)
  return { _defaultValue = defaultValue, _id = {} }
end

-- ============================================================================
-- SECTION 3: Fiber Tree & Reconciler
-- Each fiber represents a unit of work. Component fibers hold hooks state.
-- Element fibers hold layout information. The reconciler diffs old/new VNode
-- trees and marks fibers for creation, update, or deletion.
-- ============================================================================

local FiberTag = {
  PLACEMENT = 1,  -- new node, needs creation
  UPDATE    = 2,  -- existing node, props changed
  DELETION  = 3,  -- node removed
}

local function createFiber(vnode, parent)
  return {
    vnode = vnode,
    parent = parent,
    child = nil,        -- first child fiber
    sibling = nil,      -- next sibling fiber
    alternate = nil,    -- previous fiber (for diffing)
    hooks = {},         -- hooks state (components only)
    dirty = false,      -- needs re-render
    tag = FiberTag.PLACEMENT,
    layoutNode = nil,   -- computed layout result
    contextProviders = nil,
  }
end

--- Reconcile children: diff old fiber children against new VNode children
local function reconcileChildren(parentFiber, newChildren)
  local oldFiber = parentFiber.alternate and parentFiber.alternate.child
  local prevSibling = nil
  local i = 1
  
  -- build key -> old fiber map for O(1) lookups
  local oldKeyMap = {}
  local oldIndexMap = {}
  local temp = oldFiber
  local oldIdx = 1
  while temp do
    if temp.vnode and temp.vnode.key then
      oldKeyMap[temp.vnode.key] = temp
    else
      oldIndexMap[oldIdx] = temp
    end
    temp = temp.sibling
    oldIdx = oldIdx + 1
  end
  
  local usedOld = {}
  
  for idx, newVNode in ipairs(newChildren) do
    local matchedOld = nil
    
    -- try key match first, then positional match
    if newVNode.key and oldKeyMap[newVNode.key] then
      matchedOld = oldKeyMap[newVNode.key]
    elseif not newVNode.key and oldIndexMap[idx] then
      local candidate = oldIndexMap[idx]
      if candidate.vnode and not candidate.vnode.key 
         and candidate.vnode.type == newVNode.type then
        matchedOld = candidate
      end
    end
    
    local newFiber
    
    if matchedOld and matchedOld.vnode.type == newVNode.type then
      -- UPDATE: same type, reuse fiber, update props
      newFiber = createFiber(newVNode, parentFiber)
      newFiber.alternate = matchedOld
      newFiber.hooks = matchedOld.hooks  -- preserve hooks state!
      newFiber.layoutNode = matchedOld.layoutNode
      newFiber.tag = FiberTag.UPDATE
      usedOld[matchedOld] = true
    else
      -- PLACEMENT: new node
      newFiber = createFiber(newVNode, parentFiber)
      newFiber.tag = FiberTag.PLACEMENT
    end
    
    -- link into fiber tree
    if idx == 1 then
      parentFiber.child = newFiber
    elseif prevSibling then
      prevSibling.sibling = newFiber
    end
    prevSibling = newFiber
  end
  
  -- collect deletions: old fibers not reused
  local deletions = {}
  temp = oldFiber
  while temp do
    if not usedOld[temp] then
      temp.tag = FiberTag.DELETION
      deletions[#deletions + 1] = temp
    end
    temp = temp.sibling
  end
  
  return deletions
end

--- Render a fiber: if it's a component, call the function to get VNodes.
--- If it's an element, just reconcile children directly.
local function renderFiber(fiber)
  local vnode = fiber.vnode
  if not vnode then return {} end
  
  if vnode.kind == COMPONENT then
    -- set up hooks context
    HookState.currentFiber = fiber
    HookState.hookIndex = 0
    
    -- call the component function with props + children
    local props = {}
    for k, v in pairs(vnode.props) do props[k] = v end
    props.children = vnode.children
    
    local result = vnode.type(props)
    
    HookState.currentFiber = nil
    
    -- handle context providers
    if vnode.props._contextProvider then
      fiber.contextProviders = fiber.contextProviders or {}
      fiber.contextProviders[vnode.props._contextProvider] = vnode.props._contextValue
      -- inherit parent providers
      if fiber.parent and fiber.parent.contextProviders then
        for ctx, val in pairs(fiber.parent.contextProviders) do
          if not fiber.contextProviders[ctx] then
            fiber.contextProviders[ctx] = val
          end
        end
      end
    end
    
    -- normalize result to array
    if result == nil then return {} end
    if result.__vnode then return { result } end
    return result
  elseif vnode.kind == FRAGMENT then
    return vnode.children
  else
    return vnode.children
  end
end

-- ============================================================================
-- SECTION 4: Flexbox Layout Engine
-- Simplified flexbox: handles direction, justify, align, gap, padding, 
-- percentage/viewport units, and flex-grow/shrink. This is the piece FlexLöve
-- gets right that other libraries skip entirely.
-- ============================================================================

local Layout = {}

--- Resolve a dimension value to pixels
--- Supports: number (px), "50%" (parent-relative), "10vw"/"10vh" (viewport)
function Layout.resolve(value, parentSize, axis)
  if value == nil then return nil end
  if _G.type(value) == "number" then return value end
  if _G.type(value) ~= "string" then return nil end
  
  local num, unit = value:match("^([%d%.]+)(.*)$")
  num = tonumber(num)
  if not num then return nil end
  
  if unit == "%" then
    return (num / 100) * (parentSize or 0)
  elseif unit == "vw" then
    return (num / 100) * love.graphics.getWidth()
  elseif unit == "vh" then
    return (num / 100) * love.graphics.getHeight()
  elseif unit == "px" or unit == "" then
    return num
  end
  return num
end

--- Compute layout for a node and its children (single-pass flexbox)
function Layout.compute(node, parentX, parentY, parentW, parentH)
  local style = node.style or {}
  
  -- resolve own dimensions
  local w = Layout.resolve(style.width, parentW, "x") or parentW or 0
  local h_val = Layout.resolve(style.height, parentH, "y")
  
  local padL = Layout.resolve(style.paddingLeft or style.padding, w, "x") or 0
  local padR = Layout.resolve(style.paddingRight or style.padding, w, "x") or 0
  local padT = Layout.resolve(style.paddingTop or style.padding, h_val, "y") or 0
  local padB = Layout.resolve(style.paddingBottom or style.padding, h_val, "y") or 0
  
  local marL = Layout.resolve(style.marginLeft or style.margin, parentW, "x") or 0
  local marR = Layout.resolve(style.marginRight or style.margin, parentW, "x") or 0
  local marT = Layout.resolve(style.marginTop or style.margin, parentH, "y") or 0
  local marB = Layout.resolve(style.marginBottom or style.margin, parentH, "y") or 0
  
  local x = parentX + marL
  local y = parentY + marT
  
  local innerW = w - padL - padR
  local innerH = (h_val or 0) - padT - padB
  
  local direction = style.flexDirection or "column"  -- column is default (like web)
  local isRow = direction == "row"
  local gap = Layout.resolve(style.gap, isRow and innerW or innerH, isRow and "x" or "y") or 0
  local justify = style.justifyContent or "start"
  local align = style.alignItems or "start"
  local wrap = style.flexWrap == "wrap"
  
  -- first pass: measure children, collect flex info
  local children = node.children or {}
  local childLayouts = {}
  local totalFixed = 0
  local totalFlex = 0
  local maxCross = 0
  
  for i, child in ipairs(children) do
    local cs = child.style or {}
    local cw = Layout.resolve(cs.width, innerW, "x")
    local ch = Layout.resolve(cs.height, innerH, "y")
    local flexGrow = cs.flexGrow or 0
    local flexShrink = cs.flexShrink or 1
    local flexBasis = Layout.resolve(cs.flexBasis, isRow and innerW or innerH, isRow and "x" or "y")
    
    local mainSize = flexBasis or (isRow and cw or ch) or 0
    local crossSize = (isRow and ch or cw) or 0
    
    childLayouts[i] = {
      node = child,
      mainSize = mainSize,
      crossSize = crossSize,
      flexGrow = flexGrow,
      flexShrink = flexShrink,
      resolvedW = cw,
      resolvedH = ch,
    }
    
    if flexGrow > 0 then
      totalFlex = totalFlex + flexGrow
    else
      totalFixed = totalFixed + mainSize
    end
    if crossSize > maxCross then maxCross = crossSize end
  end
  
  local totalGaps = math.max(0, #children - 1) * gap
  local availableMain = (isRow and innerW or innerH) - totalFixed - totalGaps
  
  -- distribute flex space
  if totalFlex > 0 and availableMain > 0 then
    for _, cl in ipairs(childLayouts) do
      if cl.flexGrow > 0 then
        cl.mainSize = (cl.flexGrow / totalFlex) * availableMain
      end
    end
  end
  
  -- justify content: compute starting offset and spacing
  local usedMain = 0
  for _, cl in ipairs(childLayouts) do usedMain = usedMain + cl.mainSize end
  local freeMain = (isRow and innerW or innerH) - usedMain - totalGaps
  
  local mainOffset = 0
  local extraGap = 0
  if justify == "center" then
    mainOffset = freeMain / 2
  elseif justify == "end" then
    mainOffset = freeMain
  elseif justify == "space-between" and #children > 1 then
    extraGap = freeMain / (#children - 1)
  elseif justify == "space-around" and #children > 0 then
    extraGap = freeMain / #children
    mainOffset = extraGap / 2
  elseif justify == "space-evenly" and #children > 0 then
    extraGap = freeMain / (#children + 1)
    mainOffset = extraGap
  end
  
  -- second pass: position children recursively
  local cursor = mainOffset
  local contentH = 0
  
  for i, cl in ipairs(childLayouts) do
    local childX, childY, childW_final, childH_final
    
    if isRow then
      childX = x + padL + cursor
      childW_final = cl.mainSize
      childH_final = cl.resolvedH or innerH
      
      -- align items on cross axis
      if align == "center" then
        childY = y + padT + (innerH - childH_final) / 2
      elseif align == "end" then
        childY = y + padT + innerH - childH_final
      elseif align == "stretch" then
        childY = y + padT
        childH_final = innerH
      else
        childY = y + padT
      end
    else
      childY = y + padT + cursor
      childH_final = cl.mainSize
      childW_final = cl.resolvedW or innerW
      
      if align == "center" then
        childX = x + padL + (innerW - childW_final) / 2
      elseif align == "end" then
        childX = x + padL + innerW - childW_final
      elseif align == "stretch" then
        childX = x + padL
        childW_final = innerW
      else
        childX = x + padL
      end
    end
    
    -- recurse
    Layout.compute(cl.node, childX, childY, childW_final, childH_final)
    
    -- store computed layout on the node
    cl.node.computed = {
      x = childX, y = childY,
      w = childW_final, h = childH_final,
    }
    
    cursor = cursor + cl.mainSize + gap + extraGap
    
    local childBottom = (childY - y) + childH_final
    if childBottom > contentH then contentH = childBottom end
  end
  
  -- auto-height: size to content if no explicit height
  if h_val == nil then
    h_val = contentH + padT + padB
  end
  
  node.computed = {
    x = x, y = y,
    w = w, h = h_val,
  }
end

-- ============================================================================
-- SECTION 5: Renderer (Love2D paint pass)
-- Walks the retained element tree after layout and issues draw calls.
-- Each element type maps to Love2D primitives.
-- ============================================================================

local Painter = {}

--- Built-in element renderers. Users can register custom ones.
Painter.elements = {}

Painter.elements["box"] = function(node, computed)
  local style = node.style or {}
  
  -- background
  if style.backgroundColor then
    local c = style.backgroundColor
    love.graphics.setColor(c[1] or c.r or 1, c[2] or c.g or 1, c[3] or c.b or 1, c[4] or c.a or 1)
    
    local rx = style.borderRadius or 0
    if rx > 0 then
      love.graphics.rectangle("fill", computed.x, computed.y, computed.w, computed.h, rx, rx)
    else
      love.graphics.rectangle("fill", computed.x, computed.y, computed.w, computed.h)
    end
  end
  
  -- border
  if style.borderWidth and style.borderWidth > 0 then
    local c = style.borderColor or { 1, 1, 1, 1 }
    love.graphics.setColor(c[1], c[2], c[3], c[4] or 1)
    love.graphics.setLineWidth(style.borderWidth)
    local rx = style.borderRadius or 0
    love.graphics.rectangle("line", computed.x, computed.y, computed.w, computed.h, rx, rx)
  end
end

Painter.elements["text"] = function(node, computed)
  local style = node.style or {}
  local color = style.color or { 1, 1, 1, 1 }
  love.graphics.setColor(color[1], color[2], color[3], color[4] or 1)
  
  local font = style.font or love.graphics.getFont()
  love.graphics.setFont(font)
  
  local text = node.textContent or ""
  local align = style.textAlign or "left"
  
  love.graphics.printf(text, computed.x, computed.y, computed.w, align)
end

Painter.elements["image"] = function(node, computed)
  local style = node.style or {}
  if node.image then
    love.graphics.setColor(1, 1, 1, style.opacity or 1)
    local iw, ih = node.image:getDimensions()
    local sx = computed.w / iw
    local sy = computed.h / ih
    love.graphics.draw(node.image, computed.x, computed.y, 0, sx, sy)
  end
end

--- Paint the entire tree
function Painter.paint(node)
  if not node or not node.computed then return end
  
  local style = node.style or {}
  
  -- clipping (overflow: hidden)
  local clipping = style.overflow == "hidden"
  if clipping then
    love.graphics.push()
    love.graphics.setScissor(node.computed.x, node.computed.y, node.computed.w, node.computed.h)
  end
  
  -- opacity
  -- (handled per-element for now)
  
  -- render this element
  local renderer = Painter.elements[node.elementType]
  if renderer then
    renderer(node, node.computed)
  end
  
  -- render children
  if node.children then
    for _, child in ipairs(node.children) do
      Painter.paint(child)
    end
  end
  
  if clipping then
    love.graphics.setScissor()
    love.graphics.pop()
  end
end

-- ============================================================================
-- SECTION 6: Event System
-- Pointer events bubble up the tree (like DOM). We hit-test against computed
-- layout rects. This borrows Inky's approach of being input-source agnostic.
-- ============================================================================

local Events = {}

--- Hit test: find deepest node at (px, py)
function Events.hitTest(node, px, py)
  if not node or not node.computed then return nil end
  local c = node.computed
  
  -- check if point is within bounds
  if px < c.x or px > c.x + c.w or py < c.y or py > c.y + c.h then
    return nil
  end
  
  -- check children in reverse order (topmost first)
  if node.children then
    for i = #node.children, 1, -1 do
      local hit = Events.hitTest(node.children[i], px, py)
      if hit then return hit end
    end
  end
  
  -- this node is the hit target if it has event handlers
  if node.handlers and next(node.handlers) then
    return node
  end
  
  return nil
end

--- Dispatch event with bubbling
function Events.dispatch(node, eventName, eventData)
  local target = node
  while target do
    if target.handlers and target.handlers[eventName] then
      local handled = target.handlers[eventName](eventData)
      if handled == true then return true end  -- stopPropagation
    end
    target = target.parent
  end
  return false
end

-- ============================================================================
-- SECTION 7: The Application Root
-- Ties everything together. Creates the root, manages the update cycle,
-- integrates with love.update/love.draw/love.mouse*.
-- ============================================================================

local Root = {}
Root.__index = Root

function Reactor.createRoot()
  local root = setmetatable({
    fiber = nil,          -- root fiber
    retainedTree = nil,   -- the "DOM" equivalent - layout nodes
    needsReconcile = false,
    needsLayout = true,
    hoveredNode = nil,
    pressedNode = nil,
    _renderFn = nil,
  }, Root)
  
  return root
end

function Root:render(vnode)
  self._rootVNode = vnode
  self.needsReconcile = true
end

--- Internal: full reconciliation pass. Walks fiber tree, calls components,
--- diffs children, produces retained element tree.
function Root:_reconcile()
  local oldFiber = self.fiber
  
  -- create new root fiber
  self.fiber = createFiber(self._rootVNode, nil)
  self.fiber.alternate = oldFiber
  if oldFiber then
    self.fiber.hooks = oldFiber.hooks
  end
  
  -- work loop: process fibers depth-first
  HookState.pendingEffects = {}
  local deletions = {}
  
  local function processNode(fiber)
    if not fiber then return end
    
    -- render this fiber to get its children VNodes
    local childVNodes = renderFiber(fiber)
    
    -- reconcile children
    local dels = reconcileChildren(fiber, childVNodes)
    for _, d in ipairs(dels) do deletions[#deletions + 1] = d end
    
    -- process child fibers
    local child = fiber.child
    while child do
      processNode(child)
      child = child.sibling
    end
  end
  
  processNode(self.fiber)
  
  -- commit phase: build retained tree from fibers
  self.retainedTree = self:_buildRetainedTree(self.fiber)
  
  -- run effects
  for _, effect in ipairs(HookState.pendingEffects) do
    local hook = effect.fiber.hooks[effect.hookIndex]
    -- run cleanup from previous effect
    if hook.cleanup and _G.type(hook.cleanup) == "function" then
      hook.cleanup()
    end
    -- run new effect, capture cleanup
    hook.cleanup = effect.callback()
  end
  
  self.needsReconcile = false
  self.needsLayout = true
end

--- Convert fiber tree into a flat retained element tree suitable for layout/paint
function Root:_buildRetainedTree(fiber)
  if not fiber or not fiber.vnode then return nil end
  
  local vnode = fiber.vnode
  
  if vnode.kind == COMPONENT or vnode.kind == FRAGMENT then
    -- components are transparent - their children become the output
    -- but we wrap in a passthrough node to maintain hierarchy
    local children = {}
    local child = fiber.child
    while child do
      local retained = self:_buildRetainedTree(child)
      if retained then
        children[#children + 1] = retained
      end
      child = child.sibling
    end
    
    if #children == 1 then return children[1] end
    
    return {
      elementType = "box",
      style = {},
      children = children,
      handlers = {},
      computed = nil,
    }
  end
  
  if vnode.kind == TEXT then
    return {
      elementType = "text",
      style = vnode.props.style or {},
      textContent = vnode.props.value or "",
      children = {},
      handlers = {},
      computed = nil,
    }
  end
  
  -- ELEMENT: map VNode props to retained node
  local node = {
    elementType = vnode.type,
    style = vnode.props.style or {},
    textContent = vnode.props.text,
    image = vnode.props.image,
    children = {},
    handlers = {},
    computed = nil,
  }
  
  -- extract event handlers from props
  for k, v in pairs(vnode.props) do
    if k:sub(1, 2) == "on" and _G.type(v) == "function" then
      local eventName = k:sub(3, 3):lower() .. k:sub(4)  -- onClick -> click
      node.handlers[eventName] = v
    end
  end
  
  -- build children
  local child = fiber.child
  while child do
    local retained = self:_buildRetainedTree(child)
    if retained then
      retained.parent = node
      node.children[#node.children + 1] = retained
    end
    child = child.sibling
  end
  
  return node
end

--- Update: call each frame from love.update
function Root:update(dt)
  if self.needsReconcile then
    self:_reconcile()
  end
  
  -- check if any fibers are dirty (state changed)
  if self:_hasDirtyFibers(self.fiber) then
    self.needsReconcile = true
  end
  
  if self.needsLayout and self.retainedTree then
    local w = love.graphics.getWidth()
    local h = love.graphics.getHeight()
    Layout.compute(self.retainedTree, 0, 0, w, h)
    self.needsLayout = false
  end
end

function Root:_hasDirtyFibers(fiber)
  if not fiber then return false end
  if fiber.dirty then
    fiber.dirty = false
    return true
  end
  local child = fiber.child
  while child do
    if self:_hasDirtyFibers(child) then return true end
    child = child.sibling
  end
  return false
end

--- Draw: call from love.draw
function Root:draw()
  if self.retainedTree then
    Painter.paint(self.retainedTree)
  end
  love.graphics.setColor(1, 1, 1, 1)  -- reset
end

--- Mouse event handlers
function Root:mousepressed(x, y, button)
  if not self.retainedTree then return end
  local hit = Events.hitTest(self.retainedTree, x, y)
  if hit then
    self.pressedNode = hit
    Events.dispatch(hit, "press", { x = x, y = y, button = button })
  end
end

function Root:mousereleased(x, y, button)
  if not self.retainedTree then return end
  local hit = Events.hitTest(self.retainedTree, x, y)
  if hit then
    Events.dispatch(hit, "click", { x = x, y = y, button = button })
    if hit == self.pressedNode then
      Events.dispatch(hit, "release", { x = x, y = y, button = button })
    end
  end
  self.pressedNode = nil
end

function Root:mousemoved(x, y, dx, dy)
  if not self.retainedTree then return end
  local hit = Events.hitTest(self.retainedTree, x, y)
  
  if hit ~= self.hoveredNode then
    if self.hoveredNode then
      Events.dispatch(self.hoveredNode, "pointerLeave", { x = x, y = y })
    end
    if hit then
      Events.dispatch(hit, "pointerEnter", { x = x, y = y })
    end
    self.hoveredNode = hit
  end
  
  if hit then
    Events.dispatch(hit, "pointerMove", { x = x, y = y, dx = dx, dy = dy })
  end
end

function Root:textinput(text)
  -- route to focused element (TODO: focus management)
end

function Root:keypressed(key, scancode, isrepeat)
  -- route to focused element
end

-- Global schedule function (called by setState)
local _roots = {}

function Reactor._scheduleUpdate()
  for _, root in ipairs(_roots) do
    root.needsReconcile = true
  end
end

-- Override createRoot to track roots
local _origCreateRoot = Reactor.createRoot
function Reactor.createRoot()
  local root = _origCreateRoot()
  _roots[#_roots + 1] = root
  return root
end

-- ============================================================================
-- SECTION 8: Helper Components
-- Context.Provider, built-in primitives, etc.
-- ============================================================================

--- Context Provider component
function Reactor.createContext(defaultValue)
  local ctx = { _defaultValue = defaultValue, _id = {} }
  
  ctx.Provider = function(props)
    -- tag this fiber so useContext can find it
    return h(function(p)
      return p.children and p.children[1] or nil
    end, {
      _contextProvider = ctx,
      _contextValue = props.value,
    }, props.children)
  end
  
  return ctx
end

-- ============================================================================
-- SECTION 9: Convenience Setup
-- Wire into Love2D callbacks automatically.
-- ============================================================================

--- Mount a component as the root of a Love2D app.
--- Handles love.update, love.draw, and input routing.
function Reactor.mount(componentFn)
  local root = Reactor.createRoot()
  
  local origUpdate = love.update
  local origDraw = love.draw
  local origMousePressed = love.mousepressed
  local origMouseReleased = love.mousereleased
  local origMouseMoved = love.mousemoved
  
  love.update = function(dt)
    if origUpdate then origUpdate(dt) end
    root:render(h(componentFn, {}))
    root:update(dt)
  end
  
  love.draw = function()
    if origDraw then origDraw(dt) end
    root:draw()
  end
  
  love.mousepressed = function(x, y, button)
    if origMousePressed then origMousePressed(x, y, button) end
    root:mousepressed(x, y, button)
  end
  
  love.mousereleased = function(x, y, button)
    if origMouseReleased then origMouseReleased(x, y, button) end
    root:mousereleased(x, y, button)
  end
  
  love.mousemoved = function(x, y, dx, dy)
    if origMouseMoved then origMouseMoved(x, y, dx, dy) end
    root:mousemoved(x, y, dx, dy)
  end
  
  return root
end

-- Export sub-modules for advanced use
Reactor.Layout = Layout
Reactor.Painter = Painter
Reactor.Events = Events
Reactor.HookState = HookState

return Reactor
