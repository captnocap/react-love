--[[
  Example: Todo App built with Reactor
  
  This demonstrates what authoring feels like — functional components,
  hooks for state, declarative layout via style tables, event handling,
  and component composition. If you know React, this should read naturally.
  
  Drop reactor.lua in your project, require it, and go.
]]

local Reactor = require("reactor")
local h = Reactor.h
local useState = Reactor.useState
local useEffect = Reactor.useEffect
local useMemo = Reactor.useMemo
local useRef = Reactor.useRef

-- ============================================================================
-- Component: TodoItem
-- A single todo row. Receives props, fires callbacks up.
-- ============================================================================

local function TodoItem(props)
  local hovered, setHovered = useState(false)
  
  local bgColor = hovered 
    and { 0.25, 0.25, 0.3, 1 } 
    or { 0.15, 0.15, 0.2, 1 }
  
  if props.completed then
    bgColor = hovered 
      and { 0.15, 0.25, 0.15, 1 } 
      or { 0.1, 0.2, 0.1, 1 }
  end
  
  return h("box", {
    style = {
      flexDirection = "row",
      alignItems = "center",
      padding = 12,
      gap = 12,
      backgroundColor = bgColor,
      borderRadius = 8,
    },
    onPointerEnter = function() setHovered(true) end,
    onPointerLeave = function() setHovered(false) end,
    onClick = function() props.onToggle(props.id) end,
  },
    -- checkbox indicator
    h("box", {
      style = {
        width = 24, height = 24,
        borderRadius = 12,
        borderWidth = 2,
        borderColor = props.completed and { 0.4, 0.8, 0.4, 1 } or { 0.5, 0.5, 0.6, 1 },
        backgroundColor = props.completed and { 0.3, 0.7, 0.3, 1 } or { 0, 0, 0, 0 },
      },
    }),
    -- text
    h("text", {
      text = props.text,
      style = {
        color = props.completed and { 0.5, 0.5, 0.5, 1 } or { 0.9, 0.9, 0.95, 1 },
        flexGrow = 1,
        height = 20,
      },
    }),
    -- delete button
    h("box", {
      style = {
        width = 28, height = 28,
        borderRadius = 14,
        backgroundColor = hovered and { 0.6, 0.2, 0.2, 1 } or { 0, 0, 0, 0 },
        justifyContent = "center",
        alignItems = "center",
      },
      onClick = function(e)
        props.onDelete(props.id)
        return true  -- stop propagation
      end,
    },
      h("text", {
        text = "×",
        style = {
          color = hovered and { 1, 0.6, 0.6, 1 } or { 0.4, 0.4, 0.4, 1 },
          textAlign = "center",
          width = 28, height = 20,
        },
      })
    )
  )
end

-- ============================================================================
-- Component: FilterBar
-- Tab-style filter selection (All / Active / Completed)
-- ============================================================================

local function FilterButton(props)
  local hovered, setHovered = useState(false)
  local active = props.active
  
  return h("box", {
    style = {
      padding = 8,
      paddingLeft = 16,
      paddingRight = 16,
      borderRadius = 6,
      backgroundColor = active and { 0.3, 0.4, 0.8, 1 }
        or hovered and { 0.25, 0.25, 0.3, 1 }
        or { 0, 0, 0, 0 },
    },
    onClick = function() props.onSelect(props.filter) end,
    onPointerEnter = function() setHovered(true) end,
    onPointerLeave = function() setHovered(false) end,
  },
    h("text", {
      text = props.label,
      style = {
        color = active and { 1, 1, 1, 1 } or { 0.6, 0.6, 0.7, 1 },
        height = 16,
      },
    })
  )
end

local function FilterBar(props)
  local remaining = props.remaining
  
  return h("box", {
    style = {
      flexDirection = "row",
      justifyContent = "space-between",
      alignItems = "center",
      padding = 8,
    },
  },
    h("text", {
      text = remaining .. " item" .. (remaining == 1 and "" or "s") .. " left",
      style = {
        color = { 0.5, 0.5, 0.6, 1 },
        width = 120, height = 16,
      },
    }),
    h("box", {
      style = {
        flexDirection = "row",
        gap = 4,
      },
    },
      h(FilterButton, { label = "All",       filter = "all",       active = props.filter == "all",       onSelect = props.onFilterChange }),
      h(FilterButton, { label = "Active",    filter = "active",    active = props.filter == "active",    onSelect = props.onFilterChange }),
      h(FilterButton, { label = "Completed", filter = "completed", active = props.filter == "completed", onSelect = props.onFilterChange })
    )
  )
end

-- ============================================================================
-- Component: App (root)
-- Manages the todo list state, composes everything together.
-- ============================================================================

local function App(props)
  local todos, setTodos = useState({
    { id = 1, text = "Build a React-like UI framework",  completed = true },
    { id = 2, text = "Add flexbox layout engine",        completed = true },
    { id = 3, text = "Implement hooks system",           completed = false },
    { id = 4, text = "Ship the game",                    completed = false },
  })
  
  local filter, setFilter = useState("all")
  local nextId, setNextId = useState(5)
  
  -- derived state via useMemo
  local filteredTodos = useMemo(function()
    local result = {}
    for _, todo in ipairs(todos) do
      if filter == "all" 
        or (filter == "active" and not todo.completed)
        or (filter == "completed" and todo.completed) then
        result[#result + 1] = todo
      end
    end
    return result
  end, { todos, filter })
  
  local remaining = useMemo(function()
    local count = 0
    for _, todo in ipairs(todos) do
      if not todo.completed then count = count + 1 end
    end
    return count
  end, { todos })
  
  -- side effect: log to console when todos change
  useEffect(function()
    print("[Reactor] Todo count: " .. #todos .. " (" .. remaining .. " remaining)")
  end, { #todos, remaining })
  
  -- callbacks
  local function toggleTodo(id)
    setTodos(function(prev)
      local next = {}
      for _, t in ipairs(prev) do
        if t.id == id then
          next[#next + 1] = { id = t.id, text = t.text, completed = not t.completed }
        else
          next[#next + 1] = t
        end
      end
      return next
    end)
  end
  
  local function deleteTodo(id)
    setTodos(function(prev)
      local next = {}
      for _, t in ipairs(prev) do
        if t.id ~= id then next[#next + 1] = t end
      end
      return next
    end)
  end
  
  -- render
  return h("box", {
    style = {
      width = "100%",
      height = "100%",
      backgroundColor = { 0.08, 0.08, 0.12, 1 },
      justifyContent = "start",
      alignItems = "center",
      padding = 40,
    },
  },
    -- container (centered card)
    h("box", {
      style = {
        width = 500,
        backgroundColor = { 0.12, 0.12, 0.18, 1 },
        borderRadius = 16,
        borderWidth = 1,
        borderColor = { 0.2, 0.2, 0.3, 1 },
        padding = 24,
        gap = 16,
      },
    },
      -- title
      h("text", {
        text = "reactor todos",
        style = {
          color = { 0.6, 0.7, 1.0, 1 },
          textAlign = "center",
          height = 24,
          width = 452,
        },
      }),
      
      -- todo list
      h("box", {
        style = {
          gap = 8,
        },
      },
        -- map filtered todos to TodoItem components
        -- (in real use you'd have a map helper, shown inline for clarity)
        unpack((function()
          local items = {}
          for _, todo in ipairs(filteredTodos) do
            items[#items + 1] = h(TodoItem, {
              key = todo.id,
              id = todo.id,
              text = todo.text,
              completed = todo.completed,
              onToggle = toggleTodo,
              onDelete = deleteTodo,
            })
          end
          return items
        end)())
      ),
      
      -- filter bar
      h(FilterBar, {
        filter = filter,
        remaining = remaining,
        onFilterChange = setFilter,
      })
    )
  )
end

-- ============================================================================
-- Bootstrap: mount the app
-- ============================================================================

function love.load()
  love.window.setTitle("Reactor — Todo Example")
  love.window.setMode(800, 600, { resizable = true })
  
  Reactor.mount(App)
end
