--[[
  Reactor Utilities
  
  Lua doesn't have JSX's {items.map(...)} or ternary expressions inline.
  These helpers close the ergonomics gap.
]]

local Reactor = require("reactor")
local h = Reactor.h

local U = {}

--- Map an array to VNodes (replaces JSX's {items.map(item => <Component />)})
--- Usage: U.map(todos, function(todo) return h(TodoItem, { text = todo.text }) end)
function U.map(items, fn)
  local result = {}
  for i, item in ipairs(items) do
    local node = fn(item, i)
    if node then result[#result + 1] = node end
  end
  return result
end

--- Conditional render (replaces JSX's {condition && <Component />})
--- Usage: U.when(isVisible, function() return h("box", {...}) end)
function U.when(condition, renderFn)
  if condition then return renderFn() end
  return nil
end

--- If/else render (replaces JSX's {condition ? <A /> : <B />})
--- Usage: U.choose(isLoading, function() return h(Spinner) end, function() return h(Content) end)
function U.choose(condition, trueFn, falseFn)
  if condition then return trueFn() end
  if falseFn then return falseFn() end
  return nil
end

--- Merge style tables (like Object.assign for styles)
--- Usage: h("box", { style = U.style(baseStyle, isActive and activeStyle, props.style) })
function U.style(...)
  local result = {}
  local args = { ... }
  for _, s in ipairs(args) do
    if s and type(s) == "table" then
      for k, v in pairs(s) do
        result[k] = v
      end
    end
  end
  return result
end

--- Create a styled component factory (like styled-components)
--- Usage: 
---   local Card = U.styled("box", { backgroundColor = {0.2,0.2,0.3,1}, borderRadius = 12, padding = 16 })
---   -- then use: h(Card, { style = { width = 300 } }, children...)
function U.styled(elementType, baseStyle)
  return function(props)
    local mergedStyle = U.style(baseStyle, props.style)
    local newProps = {}
    for k, v in pairs(props) do
      if k ~= "style" and k ~= "children" then
        newProps[k] = v
      end
    end
    newProps.style = mergedStyle
    
    if props.children then
      return h(elementType, newProps, unpack(props.children))
    else
      return h(elementType, newProps)
    end
  end
end

--- Create a reusable theme table. Components access via useContext.
--- Usage:
---   local Theme = U.createTheme({ primary = {0.3,0.5,1,1}, bg = {0.1,0.1,0.15,1} })
---   -- in App: h(Theme.Provider, { value = myTheme }, ...)
---   -- in child: local theme = Reactor.useContext(Theme.context)
function U.createTheme(defaults)
  local ctx = Reactor.createContext(defaults)
  return {
    context = ctx,
    Provider = ctx.Provider,
    use = function() return Reactor.useContext(ctx) end,
  }
end

--- Debounced state setter (useful for search inputs, etc.)
--- Returns [value, debouncedValue, setValue]
function U.useDebouncedState(initial, delaySeconds)
  local value, setValue = Reactor.useState(initial)
  local debounced, setDebounced = Reactor.useState(initial)
  local timerRef = Reactor.useRef(0)
  
  -- in love.update, you'd check the timer. Here we approximate with useEffect.
  Reactor.useEffect(function()
    timerRef.current = love.timer.getTime() + (delaySeconds or 0.3)
    -- actual debounce needs integration with love.update timer checking
    -- for now, set immediately (TODO: proper timer integration)
    setDebounced(value)
  end, { value })
  
  return value, debounced, setValue
end

--- ForEach with keys: automatically assigns key from a field
--- Usage: U.mapKeyed(users, "id", function(user) return h(UserCard, { name = user.name }) end)
function U.mapKeyed(items, keyField, fn)
  local result = {}
  for i, item in ipairs(items) do
    local node = fn(item, i)
    if node then
      node.key = item[keyField]
      result[#result + 1] = node
    end
  end
  return result
end

--- Slot pattern: extract named children from props.children
--- Usage (in parent): h(Dialog, {}, h("box", { slot = "header" }, ...), h("box", { slot = "body" }, ...))
--- Usage (in Dialog): local slots = U.slots(props.children)
---                     return h("box", {}, slots.header, slots.body)
function U.slots(children)
  local named = {}
  local default = {}
  if children then
    for _, child in ipairs(children) do
      if child and child.props and child.props.slot then
        named[child.props.slot] = child
      else
        default[#default + 1] = child
      end
    end
  end
  named.default = default
  return named
end

return U
